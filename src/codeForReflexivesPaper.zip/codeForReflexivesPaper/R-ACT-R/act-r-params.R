## -- ACT-R parameters --
# S: the max. ass. strength
par.mas = 1.5

# d: decay parameter
par.bll = 0.5

# activation noise
#par.ans = 0.15
par.ans=0.35

# F: latency factor
par.lf = 0.14

# τ: retrieval threshold
par.rt = -1.5

# P: match scale
par.mp = 1.0

# maximum similarity
par.ms = 0

# maximum difference (penalty)
par.md = -0.6

# default action time (production firing time)
par.dat = 0.05

# s: noise in the production utility
par.egs = 0.05
#par.egs = 1.6


