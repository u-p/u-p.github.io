#-------------------------------------------------
#
# NOTE:
# . preferably 'steps' and 'stages' shouldn't be in this file unless 
#   they are assigned a relatively high value which is enough of all the models
#
#-------------------------------------------------


## -- Global vars --
currTime=0

# steps = no. of total productions
steps=8

# stages = no. of input words/stages
stages=8


currStep=0

chunkID=0
maxChunks=20

#maxRetQ=10
retQLen=0

maxCues=5

verbose=FALSE
# verbose=TRUE

verbose.func=FALSE
# verbose.func=TRUE



## -- Retrieval que --
# ret.que[*,1] = index of all chunks in the retrieval que
# ret.que[*,2] = activation of the chunk
ret.que = array(, c(retQLen,2))


## -- DM: all chunks (except goal-chunk) --
chunks = array(list(NULL), c(maxChunks,1))


## -- Syn-obj chunks --
## ?? are these only syn-obj chunks or any chunk, e.g. pic chunks?
#
# ret.hist[i,j] = time stamp of the jth retrieval of chunk i
# default value is -1 since some chunks will have 0 as creation time (1st presentation)
ret.hist = array(rep(-1,maxChunks*stages), c(maxChunks,stages))


## -- List of retrieval cues --

# cues.list[[*,1]] = feature name
# cues.list[[*,2]] = feature value
# cues.list[[*,3]] = fan
cues.list = array(, c(maxCues,3))



