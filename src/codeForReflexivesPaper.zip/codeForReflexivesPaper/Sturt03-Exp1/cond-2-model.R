
#-------------------------------------------------
#
# Model of Sturt 2003
# Sentence: She remembered that the surgeon had pricked himself with a used syringe needle (cond 2)
#
#-------------------------------------------------

#-------------------------------------------------
#
# NOTE:
# . details like creation & retrieval of IPb & CPb is not included
#
#-------------------------------------------------



## -- Goal chunk --
goal.chunk <- list(type="comprehend-sentence") #, name="", agent="", patient="")



## -- Goal buffer modification steps --

goal.steps = array(list(NULL), c(steps,1))

he <- list(NULL)
remembered <- list(NULL)
that <- list(NULL)
the <- list(NULL)
surgeon <- list(NULL)
had <- list(NULL)
pricked <- list(NULL)
himself <- list(NULL)


goal.steps[[1,1]]= he
goal.steps[[2,1]]= remembered
goal.steps[[3,1]]= that
goal.steps[[4,1]]= the
goal.steps[[5,1]]= surgeon
goal.steps[[6,1]]= had
goal.steps[[7,1]]= pricked
goal.steps[[8,1]]= himself



## -- Retrieval steps --
ret.steps = array(list(NULL), c(steps,1))

he <- list(NULL)
remembered <- list(NULL)
that <- list(type="syn-obj", cat="VP")
the <- list(NULL)
surgeon <- list(type="syn-obj", cat="DP")
had <- list(NULL)
pricked <- list(NULL)
himself <- list(type="syn-obj", cat="NP", gend="masc", role="subj", clause="sub")

ret.steps[[1,1]]= he
ret.steps[[2,1]]= remembered
ret.steps[[3,1]]= that
ret.steps[[4,1]]= the
ret.steps[[5,1]]= surgeon
ret.steps[[6,1]]= had
ret.steps[[7,1]]= pricked
ret.steps[[8,1]]= himself


## -- LHS steps --
# The LHS of the production rule that has to be satisfied
# mainly the constraints on the retrieval buffer contents.
# It's the condition that has to be satisfied before carrying
# out the creation step.

lhs.steps = array(list(NULL), c(steps,1))

he <- list(NULL)
remembered <- list(NULL)
that <- list(type="syn-obj", cat="VP")
the <- list(NULL)
surgeon <- list(type="syn-obj", cat="DP")
had <- list(NULL)
pricked <- list(NULL)
himself <- list(type="syn-obj", cat="NP")

lhs.steps[[1,1]]= he
lhs.steps[[2,1]]= remembered
lhs.steps[[3,1]]= that
lhs.steps[[4,1]]= the
lhs.steps[[5,1]]= surgeon
lhs.steps[[6,1]]= had
lhs.steps[[7,1]]= pricked
lhs.steps[[8,1]]= himself


## -- Creation steps --
# 1. VP
vp.steps = array(list(NULL), c(steps,1))
 
he <- list(NULL)
remembered <- list(type="syn-obj", name="remembered", cat="VP")
that <- list(NULL)
the <- list(NULL)
surgeon <- list(NULL)
had <- list(NULL)
pricked <- list(type="syn-obj", name="pricked", cat="VP")
himself <- list(NULL)

vp.steps[[1,1]]= he
vp.steps[[2,1]]= remembered
vp.steps[[3,1]]= that
vp.steps[[4,1]]= the
vp.steps[[5,1]]= surgeon
vp.steps[[6,1]]= had
vp.steps[[7,1]]= pricked
vp.steps[[8,1]]= himself


# 2. NP
np.steps = array(list(NULL), c(steps,1))

he <- list(type="syn-obj", name="he", cat="NP", gend="fem", role="subj", clause="main")
remembered <- list(NULL)
that <- list(NULL)
the <- list(NULL)
surgeon <- list(type="syn-obj", name="surgeon", cat="NP", gend="masc", role="subj", clause="sub")
had <- list(NULL)
pricked <- list(NULL)
himself <- list(type="syn-obj", name="himself", cat="NP", gend="masc", clause="sub")

np.steps[[1,1]]= he
np.steps[[2,1]]= remembered
np.steps[[3,1]]= that
np.steps[[4,1]]= the
np.steps[[5,1]]= surgeon
np.steps[[6,1]]= had
np.steps[[7,1]]= pricked
np.steps[[8,1]]= himself


# 3. DP
dp.steps = array(list(NULL), c(steps,1))

he <- list(NULL)
remembered <- list(NULL)
that <- list(NULL)
the <- list(type="syn-obj", name="the", cat="DP")
surgeon <- list(NULL)
had <- list(NULL)
pricked <- list(NULL)
himself <- list(NULL)

dp.steps[[1,1]]= he
dp.steps[[2,1]]= remembered
dp.steps[[3,1]]= that
dp.steps[[4,1]]= the
dp.steps[[5,1]]= surgeon
dp.steps[[6,1]]= had
dp.steps[[7,1]]= pricked
dp.steps[[8,1]]= himself


# 4. IP
ip.steps = array(list(NULL), c(steps,1))


# 5. CP
cp.steps = array(list(NULL), c(steps,1))

he <- list(NULL)
remembered <- list(NULL)
that <- list(type="syn-obj", name="that", cat="CP")
the <- list(NULL)
surgeon <- list(NULL)
had <- list(NULL)
pricked <- list(NULL)
himself <- list(NULL)


# 6. AdjP
adjp.steps = array(list(NULL), c(steps,1))


# 7. PP
pp.steps = array(list(NULL), c(steps,1))



## -- Utility values for steps --
# util.steps[*,1] = stage no.
# util.steps[*,2] = utility value of the step

util.steps = array(, c(steps,2))

he <-  c(1, 0)
remembered <-  c(2, 0)
that <-  c(3, 0)
the <-  c(4, 0)
surgeon <-  c(5, 0)
had <-  c(6, 0)
pricked <-  c(7, 0)
himself <-  c(8, 0)


util.steps[1,]= he
util.steps[2,]= remembered
util.steps[3,]= that
util.steps[4,]= the
util.steps[5,]= surgeon
util.steps[6,]= had
util.steps[7,]= pricked
util.steps[8,]= himself


## -- input stages
input.stages = c("she", "remembered", "that", "the", "surgeon", "had", "pricked", "himself")
prods.names = c("she", "remembered", "that", "the", "surgeon", "had", "pricked", "himself")


