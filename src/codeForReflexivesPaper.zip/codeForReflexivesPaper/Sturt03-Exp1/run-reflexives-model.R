

source("../R-ACT-R/functions.R")
source("../R-ACT-R/act-r-params.R")
source("../R-ACT-R/global-var.R")

# specify the number of times you want to run the model for each condition
sims = 100


#! change act-r parameter values
# noise
# ACT-R db: -1 (default), 1
# LV05: 0, 0.3
ans = c(0.3)
#ans = c(0.2, 0.22, 0.24, 0.26, 0.28, 0.3)
#ans = c(0, 0.1, 0.2, 0.3, 0.4)
#ans = c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1)

# maximum difference (penalty)
# ACT-R db: -1 (default), 1
# LV05: -0.6
md = c(-0.6)
#md = c(-1, -0.8, -0.6, -0.4, -0.2, 0)
#md = c(-1, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1, 0)

# S: the max. ass. strength
# ACT-R db: NIL (default), 1.28 to 3.45
# LV05: 1.5
mas = c(1.5)
#mas = c(1, 1.5, 2, 2.5, 3, 3.5, 4)
#mas = c(1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75, 4)

# F: latency factor
# ?? it was changed to 0.46 in VasishthEtAl-2008
#par.lf = 0.14


pars.tmp = merge(as.data.frame(ans), as.data.frame(md))
pars = merge(pars.tmp, as.data.frame(mas))
runs = length(ans)*length(md)*length(mas)
#runs = 1


for(run in c(1:runs)){
	
par.ans <<- pars[run, 1]
par.md <<- pars[run, 2]
par.mas <<- pars[run, 3]

#! "output-trace" is the directory where the trace and other output files are written to

run.model("cond-1-model.R", "./all-ans-mas-md/output-trace-1", run)
run.model("cond-2-model.R", "./all-ans-mas-md/output-trace-2", run)
run.model("cond-3-model.R", "./all-ans-mas-md/output-trace-3", run)
run.model("cond-4-model.R", "./all-ans-mas-md/output-trace-4", run)

}

