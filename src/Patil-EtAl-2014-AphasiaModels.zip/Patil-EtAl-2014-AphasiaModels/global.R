#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


#! the home directory
HOME = getwd()

#! no. of runs for each combination of parameters
sims = 1000

