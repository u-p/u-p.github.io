#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


#! start fresh
rm(list=ls())
source("global.R")

#! load libraries & functions
#library(plyr)
library("binom")

source("R-functions/mylegend.R")
source("R-functions/errorbar.R")
source("R-functions/se.R")

#! load model predictions
cont = read.table("R-ACT-R/predictions/pred.fixParam.cont-n0.3.txt", header=TRUE)[1,]
tdhv1 = read.table("R-ACT-R/predictions/pred.fixParam.tdhv1-n0.3.txt", header=TRUE)[1,]
tdhv2 = read.table("R-ACT-R/predictions/pred.fixParam.tdhv2-n0.3.txt", header=TRUE)[1,]
m1 = read.table("R-ACT-R/predictions/pred.param.m1-n0.3.txt", header=TRUE)
m2 = read.table("R-ACT-R/predictions/pred.param.m2-n0.3.txt", header=TRUE)
m3 = read.table("R-ACT-R/predictions/pred.param.m3-n0.3.txt", header=TRUE)

#! remove trailing characters in the subject id
cont$subj = substr(cont$subj, 1,2)
tdhv1$subj = substr(tdhv1$subj, 1,2)
tdhv2$subj = substr(tdhv2$subj, 1,2)
m1$subj = substr(m1$subj, 1,2)
m2$subj = substr(m2$subj, 1,2)
m3$subj = substr(m3$subj, 1,2)

#! load data
acc.dt = read.table("data/Accuracy-data.txt", header=TRUE)
em.dt = read.table("data/em-data.txt", header=TRUE)
rt.dt = read.table("data/RT-data.txt", header=TRUE)

dt.cont.sum = read.table("data/dt-cont-sum.txt", header=TRUE)
dt.iwa.sum  = read.table("data/dt-iwa-sum.txt", header=TRUE)



###############################
# Plot accuracies
###############################

# data

acc.data = as.matrix(cbind(c(mean(dt.cont.sum$ACC.SVO), mean(dt.cont.sum$ACC.OVS)), 
								  c(mean(dt.iwa.sum$ACC.SVO), mean(dt.iwa.sum$ACC.OVS))
								  )
							)
							
acc.data.se = as.matrix(cbind(c(se(dt.cont.sum$ACC.SVO), se(dt.cont.sum$ACC.OVS)), 
								  c(se(dt.iwa.sum$ACC.SVO), se(dt.iwa.sum$ACC.OVS))
								  )
							)
							
colnames(acc.data) = c("Controls", "Patients")

c1 = colors()[194]
c2 = colors()[230]

pdf("plots/data-acc.pdf")
#cols=c("black", "gray", "black", "gray")
cols=c(c1,c2,c1,c2)
pos = barplot(
			acc.data, beside=TRUE, space=c(0,.5), 
			ylim=c(0,100), cex.axis=2, cex.names=2, col=cols,
			legend.text=c("Canonical", "Non-canonical"), args.legend=list(cex=1.2),
			main="Accuracy (%)", cex.main=2
			)
#error.bar(pos, acc.data, acc.data.se, col=c("gray", "black", "gray", "black"), lwd=2)
error.bar(pos, acc.data, acc.data.se, lwd=2)

dev.off()


# using the Clopper-Pearson (or the 'exact') method to calculate CI's for accuracies

n = sims # no. of trials = no. of runs of the model
#! convert percentages to counts (=no. of successes)
cont.acc.can = cont$acc.can * n /100
cont.acc.noncan = cont$acc.noncan * n /100
tdhv1.acc.can = tdhv1$acc.can * n /100
tdhv1.acc.noncan = tdhv1$acc.noncan * n /100
tdhv2.acc.can = tdhv2$acc.can * n /100
tdhv2.acc.noncan = tdhv2$acc.noncan * n /100

upper = c(binom.confint(x = c(cont.acc.can, cont.acc.noncan, tdhv1.acc.can, 
						 tdhv1.acc.noncan, tdhv2.acc.can, tdhv2.acc.noncan), 
					n, conf.level = 0.95, methods = "exact")$upper*100, 
					c(mean(m1$acc.can)+se(m1$acc.can), mean(m1$acc.noncan)+se(m1$acc.noncan)), 
					c(mean(m2$acc.can)+se(m2$acc.can), mean(m2$acc.noncan)+se(m2$acc.noncan)), 
					c(mean(m3$acc.can)+se(m3$acc.can), mean(m3$acc.noncan)+se(m3$acc.noncan))
			)

lower = c(binom.confint(x = c(cont.acc.can, cont.acc.noncan, tdhv1.acc.can, 
						 tdhv1.acc.noncan, tdhv2.acc.can, tdhv2.acc.noncan), 
					n, conf.level = 0.95, methods = "exact")$lower*100, 
					c(mean(m1$acc.can)-se(m1$acc.can), mean(m1$acc.noncan)-se(m1$acc.noncan)), 
					c(mean(m2$acc.can)-se(m2$acc.can), mean(m2$acc.noncan)-se(m2$acc.noncan)), 
					c(mean(m3$acc.can)-se(m3$acc.can), mean(m3$acc.noncan)-se(m3$acc.noncan))
			)

acc.mod = as.matrix(cbind(c(cont$acc.can, cont$acc.noncan), 
								c(tdhv1$acc.can, tdhv1$acc.noncan), 
								c(tdhv2$acc.can, tdhv2$acc.noncan), 
								c(mean(m1$acc.can), mean(m1$acc.noncan)), 
								c(mean(m2$acc.can), mean(m2$acc.noncan)), 
								c(mean(m3$acc.can), mean(m3$acc.noncan))
						))

# modified 'error.bar' function
error.bar2 <- function(x, y, upper, lower=upper, length=0.05,...){
	if(length(x) != length(y) | length(y) !=length(lower) | length(lower) != length(upper))
	stop("vectors must be same length")
	arrows(x, upper, x, lower, angle=90, code=3, length=length, ...)
}

colnames(acc.mod) = c("Controls", "TDH-1", "TDH-2", "M1", "M2", "M3")

pdf("plots/model-acc.pdf", width=12)
#cols=c("black", "gray", "black", "gray", "black", "gray", "black", "gray", "black", "gray", "black", "gray")
cols=c(c1,c2,c1,c2,c1,c2,c1,c2,c1,c2,c1,c2)
pos = barplot(
			acc.mod, beside=TRUE, space=c(0,.5), 
			ylim=c(0,110), cex.axis=2, cex.names=2, col=cols,
			legend.text=c("Canonical", "Non-canonical"), args.legend=list(cex=1.5),
			main="Accuracy (%)", cex.main=2
			)
#error.bar2(pos, acc.mod, upper, lower, col=c("gray", "black", "gray", "black", "gray", "black", "gray", "black", "gray", "black", "gray", "black"), lwd=2)
error.bar2(pos, acc.mod, upper, lower, lwd=2)
dev.off()



###############################
# Plot RTs
###############################

#! data
rt.dt$subj = ifelse(rt.dt$subj=="cont", "Controls", "Patients")
rt.dt$cond = ifelse(rt.dt$cond=="can", "Canonical", "Non-canonical")
rt.cont = subset(rt.dt, subj=="Controls")
rt.m3 = subset(rt.dt, subj=="Patients")

rts = as.matrix(cbind(rt.cont[,4], rt.m3[, 4]))
colnames(rts) = c("Controls", "Patients")

leg = c("Correct : Canonical", "Correct : Non-canonical", "Incorrect : Canonical", "Incorrect : Non-canonical")


pdf("plots/data-rt.pdf")
pos = barplot(rts, beside=TRUE, ylim=c(0, 6500), cex.names=2, 
				yaxt="n", 
				legend=leg, args.legend=list(x="topleft", cex=1.2), 
				main = "Response time (ms)", cex.main=2,
#				col=c("black", "black", "gray", "gray")
				)

axis(2, at=c(0,2000, 4000, 6000), labels=c(0,2000, 4000, 6000), cex.axis=2)
error.bar(pos[,1], rts[,1], rt.cont[,5], lwd=2)
error.bar(pos[,2], rts[,2], rt.m3[,5], lwd=2)
dev.off()


#! models

rts.mod = as.matrix(cbind(
          c(cont$rt.can.cor, cont$rt.noncan.cor, cont$rt.can.incor, cont$rt.noncan.incor), 
          c(tdhv1$rt.can.cor, tdhv1$rt.noncan.cor, tdhv1$rt.can.incor, tdhv1$rt.noncan.incor), 
          c(tdhv2$rt.can.cor, tdhv2$rt.noncan.cor, tdhv2$rt.can.incor, tdhv2$rt.noncan.incor), 
          c(mean(m1$rt.can.cor, na.rm=TRUE), mean(m1$rt.noncan.cor, na.rm=TRUE), mean(m1$rt.can.incor, na.rm=TRUE), mean(m1$rt.noncan.incor, na.rm=TRUE)), 
          c(mean(m2$rt.can.cor, na.rm=TRUE), mean(m2$rt.noncan.cor, na.rm=TRUE), mean(m2$rt.can.incor, na.rm=TRUE), mean(m2$rt.noncan.incor, na.rm=TRUE)), 
          c(mean(m3$rt.can.cor, na.rm=TRUE), mean(m3$rt.noncan.cor, na.rm=TRUE), mean(m3$rt.can.incor, na.rm=TRUE), mean(m3$rt.noncan.incor, na.rm=TRUE))
          )
        )
colnames(rts.mod) = c("Controls", "TDH-1", "TDH-2", "M1", "M2", "M3")

se.mod = as.matrix(cbind(
					c(cont$se.can.cor, cont$se.noncan.cor, cont$se.can.incor, cont$se.noncan.incor), 
					c(tdhv1$se.can.cor, tdhv1$se.noncan.cor, tdhv1$se.can.incor, tdhv1$se.noncan.incor), 
					c(tdhv2$se.can.cor, tdhv2$se.noncan.cor, tdhv2$se.can.incor, tdhv2$se.noncan.incor), 
#
# Note: the SE's from simulations are not used, but they are recalculated from individual RT
# that's because now we have a distribution of predicted RTs (individual parameters & predictions 
# for aphasics (m1, m2 & m3))
					c(se(m1$rt.can.cor), se(m1$rt.noncan.cor), se(m1$rt.can.incor), se(m1$rt.noncan.incor)), 
					c(se(m2$rt.can.cor), se(m2$rt.noncan.cor), se(m2$rt.can.incor), se(m2$rt.noncan.incor)), 
					c(se(m3$rt.can.cor), se(m3$rt.noncan.cor), se(m3$rt.can.incor), se(m3$rt.noncan.incor))
#					c(m1$se.can.cor, m1$se.noncan.cor, m1$se.can.incor, m1$se.noncan.incor), 
#					c(m2$se.can.cor, m2$se.noncan.cor, m2$se.can.incor, m2$se.noncan.incor), 
#					c(m3$se.can.cor, m3$se.noncan.cor, m3$se.can.incor, m3$se.noncan.incor)
					)
				)

pdf("plots/model-rt.pdf", width=12, height=8)
pos = barplot(rts.mod, beside=TRUE, ylim=c(0, 6500), cex.names=2, 
				yaxt="n", 
				legend=leg, args.legend=list(x="topleft", cex=1.5), 
				main = "Response time (ms)", cex.main=2,
#				col=c("black", "black", "gray", "gray")
				)
axis(2, at=c(0,2000, 4000, 6000, 8000, 10000), labels=c(0,2000, 4000, 6000, 8000, 10000), cex.axis=2)

error.bar(pos[,1], rts.mod[,1], se.mod[,1], lwd=2)
error.bar(pos[,2], rts.mod[,2], se.mod[,2], lwd=2)
error.bar(pos[,3], rts.mod[,3], se.mod[,3], lwd=2)
error.bar(pos[,4], rts.mod[,4], se.mod[,4], lwd=2)
error.bar(pos[,5], rts.mod[,5], se.mod[,5], lwd=2)
error.bar(pos[,6], rts.mod[,6], se.mod[,6], lwd=2)
dev.off()



##############################################################
# Plot parameters: 
#   Comparison of parameters for aphasics vs. controls
##############################################################

#par(mfrow=c(1,1))

cont.ind = read.table(file="R-ACT-R/predictions/pred.param.cont.ind-n0.3.txt", header=TRUE)

yaxt = c(0.02, 0.04, 0.06, 0.08)
xaxt = c(0.05, 0.10, 0.15, 0.20)
col.cont	= colors()[210] # darker than "gray"
col.m3		= "black"
default.util.noise = 0.01
default.DAT = 0.02

pdf("plots/param-compare.pdf")

par(mgp = c(2,0.5,0)) # set the distance between the labels (xlab, ylab) & tick mark labels from the axes
plot(0,
		xlim=c(min(cont.ind$prod.noise), max(m3$prod.noise)),
		ylim=c(min(cont.ind$prod.tm), max(m3$prod.tm)),
		type="n", xlab="Utility noise", ylab="Default action time", cex.lab=1.7, 
		main="Individual parameter values", cex.main=2, 
		yaxt="n", xaxt="n"
		)
box(lwd=3)

points(jitter(as.numeric(cont.ind$prod.noise)), jitter(as.numeric(cont.ind$prod.tm)), pch=23, cex=1.8, bg=col.cont, col="white")
x.jit = jitter(as.numeric(m3$prod.noise), 2)
y.jit = jitter(as.numeric(m3$prod.tm), 2)

points(x.jit, y.jit, pch=21, cex=2, bg=col.m3, col="white")
points(default.util.noise, default.DAT, pch=23, cex=1.8, bg="black", col="white")
legend("topleft", legend=c("Fixed", "Controls", "Patients"), pch=c(23, 23, 21), cex=1.5, pt.bg=c("black", col.cont, col.m3), col="white")
text(x.jit, y.jit - 0.004, m3$subj)

axis(2, at=yaxt, labels=yaxt, cex.axis=1.3)
axis(1, at=xaxt, labels=xaxt, cex.axis=1.3)

dev.off()


##############################################################
# Plot NRMSDs
##############################################################

# NRMSDs for both measures combined (5 models of IWAs)

tdhv1.ind = read.table("R-ACT-R/predictions/pred.fixParam.tdhv1-n0.3.txt", header=TRUE)
tdhv2.ind = read.table("R-ACT-R/predictions/pred.fixParam.tdhv2-n0.3.txt", header=TRUE)

nrmsd.comb = 
(matrix(cbind(
              round(tdhv1.ind[order(tdhv1.ind$subj),c(7)], 2), 
              round(tdhv2.ind[order(tdhv2.ind$subj),c(7)], 2), 
              round(m1[order(m1$subj),c(7)], 2), 
              round(m2[order(m2$subj),c(7)], 2), 
              round(m3[order(m3$subj),c(7)], 2)
              ), nrow=7, ncol=5
            )
 )

colnames(nrmsd.comb) = c("tdhv1", "tdhv2", "m1", "m2", "m3")  #c("subj", "tdhv1", "tdhv2", "m1", "m2", "m3")
rownames(nrmsd.comb) = as.character(m1[order(m1$subj),4])

pdf("plots/nrmsd-comb.pdf", width=12, height=8)
barplot(t(nrmsd.comb), beside=TRUE, ylim=c(0,2),
        main="NRMSD values", cex.main=2,
        legend.text=c("TDH-1", "TDH-2", "M1", "M2", "M3"),
        args.legend=list(x="topleft", cex=1)
        )
dev.off()


###############################
# Plot eye movements
###############################


cont.can.cor = c(em.dt[1,]$np1, em.dt[1,]$verb, em.dt[1,]$np2, em.dt[1,]$silence)
cont.noncan.cor = c(em.dt[2,]$np1, em.dt[2,]$verb, em.dt[2,]$np2, em.dt[2,]$silence)

iwa.can.cor = c(em.dt[3,]$np1, em.dt[3,]$verb, em.dt[3,]$np2, em.dt[3,]$silence)
iwa.noncan.cor = c(em.dt[4,]$np1, em.dt[4,]$verb, em.dt[4,]$np2, em.dt[4,]$silence)
iwa.can.incor = c(em.dt[5,]$np1, em.dt[5,]$verb, em.dt[5,]$np2, em.dt[5,]$silence)
iwa.noncan.incor = c(em.dt[6,]$np1, em.dt[6,]$verb, em.dt[6,]$np2, em.dt[6,]$silence)

xlim = c(0.8,4.2)
ylim.r = c(-2.5,2.5)
ylim.l = c(0,100)

lty.cont = lty.iwa = ltw.tdh1 = 2
lty.m1  = ltw.tdh2 = 3
lty.m2  = 6

labs=c("NP1", "Verb", "NP2", "Silence")
ylab.l = "        Correct     fixations (%)"
ylab.r = "Activation    difference"

jit.f = 0.1 # jitter factor

lwd.pl = 5
pch.cex = 3

c.main = 2.5

# ------- controls -------
# SVO (correct)
pdf("plots/em-cont-can.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(A) Controls : Canonical (correct resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(cont.can.cor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(  c(cont$act.diff.can.cor.np1, cont$act.diff.can.cor.vp, cont$act.diff.can.cor.np2, cont$act.diff.can.cor.sil), 
        type="b", pch=20, lwd=lwd.pl, lty=lty.cont, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

my.legend(x=1.85, y=-1.25, legend=c("Data", "Model"), lwd=3, lty=c(1, lty.cont), pch=c(18, 20), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
rect(1.75,-2.5,3.25,-1.35, lwd=2)

dev.off()


# OVS (correct)
pdf("plots/em-cont-noncan.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(B) Controls : Non-canonical (correct resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(cont.noncan.cor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(	c(cont$act.diff.noncan.cor.np1, cont$act.diff.noncan.cor.vp, cont$act.diff.noncan.cor.np2, cont$act.diff.noncan.cor.sil), 
       type="b", pch=20, lwd=lwd.pl, lty=lty.cont, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)
dev.off()



# ------- iwa -------
# SVO (correct)
pdf("plots/em-iwa-can-cor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(A) Patients : Canonical (correct resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.can.cor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(mean(m3$act.diff.can.cor.np1), mean(m3$act.diff.can.cor.vp), 
        mean(m3$act.diff.can.cor.np2), mean(m3$act.diff.can.cor.sil)), 
      type="b", pch=21, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m1$act.diff.can.cor.np1), mean(m1$act.diff.can.cor.vp), 
        mean(m1$act.diff.can.cor.np2), mean(m1$act.diff.can.cor.sil)), 
      type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m2$act.diff.can.cor.np1), mean(m2$act.diff.can.cor.vp), 
        mean(m2$act.diff.can.cor.np2), mean(m2$act.diff.can.cor.sil)), 
      type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

my.legend(x=1.85, y=-0.5, legend=c("Data", "M1", "M2", "M3"), lwd=3, lty=c(1, lty.m1, lty.m2, lty.iwa), pch=c(18, 22, 24, 21), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
rect(1.75,-2.5,3.2,-0.5, lwd=2)
dev.off()

# TDH
pdf("plots/em-tdh-can-cor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(C) Patients : Canonical (correct resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.can.cor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(tdhv1$act.diff.can.cor.np1, tdhv1$act.diff.can.cor.vp, tdhv1$act.diff.can.cor.np2, tdhv1$act.diff.can.cor.sil), 
      type="b", pch=24, lwd=lwd.pl, lty=ltw.tdh1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(tdhv2$act.diff.can.cor.np1, tdhv2$act.diff.can.cor.vp, tdhv2$act.diff.can.cor.np2, tdhv2$act.diff.can.cor.sil), 
      type="b", pch=22, lwd=lwd.pl, lty=ltw.tdh2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

my.legend(x=1.85, y=-0.5, legend=c("Data", "TDH-1", "TDH-2"), lwd=3, lty=c(1, ltw.tdh1, ltw.tdh2), pch=c(18, 24, 22), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
rect(1.75,-2.2,3.3,-0.5, lwd=2)
dev.off()


# OVS (correct)
pdf("plots/em-iwa-noncan-cor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(B) Patients : Non-canonical (correct resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.noncan.cor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(mean(m3$act.diff.noncan.cor.np1), mean(m3$act.diff.noncan.cor.vp), 
        mean(m3$act.diff.noncan.cor.np2), mean(m3$act.diff.noncan.cor.sil)), 
      type="b", pch=21, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m1$act.diff.noncan.cor.np1), mean(m1$act.diff.noncan.cor.vp), 
        mean(m1$act.diff.noncan.cor.np2), mean(m1$act.diff.noncan.cor.sil)), 
      type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m2$act.diff.noncan.cor.np1), mean(m2$act.diff.noncan.cor.vp), 
        mean(m2$act.diff.noncan.cor.np2), mean(m2$act.diff.noncan.cor.sil)), 
      type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)
#lines(jitter(c(1:4), jit.f), 
#		c(m3$act.diff.noncan.cor.np1, m3$act.diff.noncan.cor.vp, m3$act.diff.noncan.cor.np2, m3$act.diff.noncan.cor.sil), 
#		type="b", pch=20, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)
#
#lines(jitter(c(1:4), jit.f), 
#		c(m1$act.diff.noncan.cor.np1, m1$act.diff.noncan.cor.vp, m1$act.diff.noncan.cor.np2, m1$act.diff.noncan.cor.sil), 
#		type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)
#
#lines(jitter(c(1:4), jit.f), 
#		c(m2$act.diff.noncan.cor.np1, m2$act.diff.noncan.cor.vp, m2$act.diff.noncan.cor.np2, m2$act.diff.noncan.cor.sil), 
#		type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

#my.legend(x=1.85, y=-0.5, legend=c("Data", "M1", "M2", "M3"), lwd=3, lty=c(1, lty.m1, lty.m2, lty.iwa), pch=c(18, 22, 24, 20), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
#rect(1.75,-2.25,2.85,-0.5, lwd=2)
dev.off()

# TDH
pdf("plots/em-tdh-noncan-cor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(D) Patients : Non-canonical (correct resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.noncan.cor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(tdhv1$act.diff.noncan.cor.np1, tdhv1$act.diff.noncan.cor.vp, tdhv1$act.diff.noncan.cor.np2, tdhv1$act.diff.noncan.cor.sil), 
      type="b", pch=24, lwd=lwd.pl, lty=ltw.tdh1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(tdhv2$act.diff.noncan.cor.np1, tdhv2$act.diff.noncan.cor.vp, tdhv2$act.diff.noncan.cor.np2, tdhv2$act.diff.noncan.cor.sil), 
      type="b", pch=22, lwd=lwd.pl, lty=ltw.tdh2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

#my.legend(x=1.85, y=-0.5, legend=c("Data", "TDH-1", "TDH-2"), lwd=3, lty=c(1, lty.m1, lty.m2), pch=c(18, 24, 22), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
#rect(1.75,-2,3,-0.5, lwd=2)

dev.off()


# SVO (incorrect)
pdf("plots/em-iwa-can-incor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(C) Patients : Canonical (incorrect resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.can.incor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(mean(m3$act.diff.can.incor.np1), mean(m3$act.diff.can.incor.vp), 
        mean(m3$act.diff.can.incor.np2), mean(m3$act.diff.can.incor.sil)), 
      type="b", pch=21, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m1$act.diff.can.incor.np1), mean(m1$act.diff.can.incor.vp), 
        mean(m1$act.diff.can.incor.np2), mean(m1$act.diff.can.incor.sil)), 
      type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m2$act.diff.can.incor.np1), mean(m2$act.diff.can.incor.vp), 
        mean(m2$act.diff.can.incor.np2), mean(m2$act.diff.can.incor.sil)), 
      type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)
#lines(jitter(c(1:4), jit.f), 
#		c(m3$act.diff.can.incor.np1, m3$act.diff.can.incor.vp, m3$act.diff.can.incor.np2, m3$act.diff.can.incor.sil), 
#		type="b", pch=20, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)
#
#lines(jitter(c(1:4), jit.f), 
#		c(m1$act.diff.can.incor.np1, m1$act.diff.can.incor.vp, m1$act.diff.can.incor.np2, m1$act.diff.can.incor.sil), 
#		type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)
#
#lines(jitter(c(1:4), jit.f), 
#		c(m2$act.diff.can.incor.np1, m2$act.diff.can.incor.vp, m2$act.diff.can.incor.np2, m2$act.diff.can.incor.sil), 
#		type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

#my.legend(x=1.85, y=-0.5, legend=c("Data", "M1", "M2", "M3"), lwd=3, lty=c(1, lty.m1, lty.m2, lty.iwa), pch=c(18, 22, 24, 20), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
#rect(1.75,-2.25,2.85,-0.5, lwd=2)
dev.off()

# TDH
pdf("plots/em-tdh-can-incor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(E) Patients : Canonical (incorrect resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.can.incor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(tdhv1$act.diff.can.incor.np1, tdhv1$act.diff.can.incor.vp, tdhv1$act.diff.can.incor.np2, tdhv1$act.diff.can.incor.sil), 
      type="b", pch=24, lwd=lwd.pl, lty=ltw.tdh1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(tdhv2$act.diff.can.incor.np1, tdhv2$act.diff.can.incor.vp, tdhv2$act.diff.can.incor.np2, tdhv2$act.diff.can.incor.sil), 
      type="b", pch=22, lwd=lwd.pl, lty=ltw.tdh2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

#my.legend(x=1.85, y=-0.5, legend=c("Data", "TDH-1", "TDH-2"), lwd=3, lty=c(1, lty.m1, lty.m2), pch=c(18, 24, 22), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
#rect(1.75,-2,3,-0.5, lwd=2)

dev.off()


# OVS (incorrect)
pdf("plots/em-iwa-noncan-incor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(D) Patients : Non-canonical (incorrect resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.noncan.incor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(mean(m3$act.diff.noncan.incor.np1), mean(m3$act.diff.noncan.incor.vp), 
        mean(m3$act.diff.noncan.incor.np2), mean(m3$act.diff.noncan.incor.sil)), 
      type="b", pch=21, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m1$act.diff.noncan.incor.np1), mean(m1$act.diff.noncan.incor.vp), 
        mean(m1$act.diff.noncan.incor.np2), mean(m1$act.diff.noncan.incor.sil)), 
      type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(mean(m2$act.diff.noncan.incor.np1), mean(m2$act.diff.noncan.incor.vp), 
        mean(m2$act.diff.noncan.incor.np2), mean(m2$act.diff.noncan.incor.sil)), 
      type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)
#lines(jitter(c(1:4), jit.f), 
#		c(m3$act.diff.noncan.incor.np1, m3$act.diff.noncan.incor.vp, m3$act.diff.noncan.incor.np2, m3$act.diff.noncan.incor.sil), 
#		type="b", pch=20, lwd=lwd.pl, lty=lty.iwa, cex=pch.cex)
#
#lines(jitter(c(1:4), jit.f), 
#		c(m1$act.diff.noncan.incor.np1, m1$act.diff.noncan.incor.vp, m1$act.diff.noncan.incor.np2, m1$act.diff.noncan.incor.sil), 
#		type="b", pch=22, lwd=lwd.pl, lty=lty.m1, cex=pch.cex)
#
#lines(jitter(c(1:4), jit.f), 
#		c(m2$act.diff.noncan.incor.np1, m2$act.diff.noncan.incor.vp, m2$act.diff.noncan.incor.np2, m2$act.diff.noncan.incor.sil), 
#		type="b", pch=24, lwd=lwd.pl, lty=lty.m2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

#my.legend(x=1.85, y=-0.5, legend=c("Data", "M1", "M2", "M3"), lwd=3, lty=c(1, lty.m1, lty.m2, lty.iwa), pch=c(18, 22, 24, 20), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
#rect(1.75,-2.25,2.85,-0.5, lwd=2)
dev.off()

# TDH
pdf("plots/em-tdh-noncan-incor.pdf", width=10)
plot(-100, type="b", ylab="", ylim=ylim.l, xlim=xlim, xaxt="n", main="(F) Patients : Non-canonical (incorrect resp.)", xlab="", axes=FALSE, cex.main=c.main, cex.lab=1.5)
lines(c(0,5), c(50,50))
lines(iwa.noncan.incor, type="b", pch=18, lwd=lwd.pl, cex=pch.cex)
axis(1, at=1:4, labels=labs, cex.axis=2)
axis(2, at=c(0:10)*10, cex.axis=2)
mtext(ylab.l, side=2, line=-3, cex=2.5)

par(new=TRUE)
plot(-100, type="b", ylab="", ylim=ylim.r, xlim=xlim, xaxt="n", xlab="", axes=FALSE)

lines(jitter(c(1:4), jit.f), 
      c(tdhv1$act.diff.noncan.incor.np1, tdhv1$act.diff.noncan.incor.vp, tdhv1$act.diff.noncan.incor.np2, tdhv1$act.diff.noncan.incor.sil), 
      type="b", pch=24, lwd=lwd.pl, lty=ltw.tdh1, cex=pch.cex)

lines(jitter(c(1:4), jit.f), 
      c(tdhv2$act.diff.noncan.incor.np1, tdhv2$act.diff.noncan.incor.vp, tdhv2$act.diff.noncan.incor.np2, tdhv2$act.diff.noncan.incor.sil), 
      type="b", pch=22, lwd=lwd.pl, lty=ltw.tdh2, cex=pch.cex)

axis(4, at=-2.5:2.5, cex.axis=2)
mtext(ylab.r, side=4, line=-2, cex=2.5)

#my.legend(x=1.85, y=-0.5, legend=c("Data", "TDH-1", "TDH-2"), lwd=3, lty=c(1, lty.m1, lty.m2), pch=c(18, 24, 22), cex=2, pt.cex=pch.cex, pt.lwd=lwd.pl, seg.len=6, bty="n")
#rect(1.75,-2,3,-0.5, lwd=2)

dev.off()







