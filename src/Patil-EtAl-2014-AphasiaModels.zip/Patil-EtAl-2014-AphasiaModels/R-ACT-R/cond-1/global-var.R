# 
# Author: Umesh Patil (umesh.patil@gmail.com)
#

#! time tracker
currTime=0


#! steps = no. of all possible retrieval-attachment pairs.
#! If there are multiple options at a stage they are counted separately.
steps=16		# aphasia for cond-1 (SVO)
#steps=18		# aphasia for cond-2 (OVS)


#! stages = no. of input words/stages
stages=12		# aphasia for cond-1 (SVO)
#stages=13		# aphasia for cond-2 (OVS)


#! step tracker
currStep=0


#! tracker & limit for memory chunks
chunkID=0
maxChunks=20


#! length of the retrieval que
#maxRetQ=10
retQLen=0

maxCues=5


#! Print trace & function calls to stdout
verbose=FALSE
#verbose=TRUE
verbose.func=FALSE
#verbose.func=TRUE




## -- Retrieval que --
# ret.que[*,1] = index of all chunks in the retrieval que
# ret.que[*,2] = activation of the chunk
ret.que = array(, c(retQLen,2))


## -- DM: all chunks (except goal-chunk) --
chunks = array(list(NULL), c(maxChunks,1))


## -- Syn-obj chunks --
## ?? are these only syn-obj chunks or any chunk, e.g. pic chunks?
#
# ret.hist[i,j] = time stamp of the jth retrieval of chunk i
# default value is -1 since some chunks will have 0 as creation time (1st presentation)
ret.hist = array(rep(-1,maxChunks*stages), c(maxChunks,stages))


## -- List of retrieval cues --

# cues.list[[*,1]] = feature name
# cues.list[[*,2]] = feature value
# cues.list[[*,3]] = fan
cues.list = array(, c(maxCues,3))



