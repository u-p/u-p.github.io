
#-------------------------------------------------
#
# Model of Hanne, Sekerina, Vasishth, Burchert & De Bleser 2010
# Sentence: Der Sohn faengt den Vater (cond 1, SVO)
#
# 
# Author: Umesh Patil (umesh.patil@gmail.com)
#
#-------------------------------------------------



## -- Goal chunk --
goal.chunk <- list(type="comprehend-sentence", name="", agent="", theme="")
# 'name' missing


## -- Picture chunks --
pic.chunks = array(list(NULL), c(2,1))

# ctime: creation time
# npres: no. of presentations

pic1 <- list(type="pic-obj", ctime=0, npres=1, name="pic-canon", agent="Sohn-lex", theme="Vater-lex")
pic2 <- list(type="pic-obj", ctime=0, npres=1, name="pic-noncanon", agent="Vater-lex", theme="Sohn-lex")

#pic.chunks[[1,1]]=pic1
#pic.chunks[[2,1]]=pic2



## -- Goal buffer modification steps --

goal.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(agent="Sohn-lex")
tRole1.b <- list(theme="Sohn-lex")
tRole1.tdh <- list(agent="Sohn-lex")
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(theme="Vater-lex")
tRole2.b <- list(agent="Vater-lex")
tRole2.tdh <- list(theme="Vater-lex")
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

goal.steps[[1,1]]=empty
goal.steps[[2,1]]=der
goal.steps[[3,1]]=sohn
goal.steps[[4,1]]=p.match.np1
goal.steps[[5,1]]=faengt
goal.steps[[6,1]]=tRole1.a
goal.steps[[7,1]]=tRole1.b
goal.steps[[8,1]]=tRole1.tdh
goal.steps[[9,1]]=p.match.vp
goal.steps[[10,1]]=den
goal.steps[[11,1]]=vater
goal.steps[[12,1]]=tRole2.a
goal.steps[[13,1]]=tRole2.b
goal.steps[[14,1]]=tRole2.tdh
goal.steps[[15,1]]=p.match.np2
goal.steps[[16,1]]=p.match.end


## -- Retrieval steps --
ret.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
der <- list(type="syn-obj", cat="DP", case="nom", name="empty-der") # retrieve the predicted nominative DP; 'name="empty-der"' here signifies that the head is empty (= retrieve that nominative DP which has an empty head)
sohn <- list(type="syn-obj", cat="DP", case="nom")
p.match.np1 <- list(type="pic-obj", agent="", theme="")
faengt <- list(type="syn-obj", cat="CP")
tRole1.a <- list(type="syn-obj", cat="DP", case="nom") # note: case marking only for correct retrieval and NOT for theta role assignment; theta roles are assigned using the trace information
tRole1.b <- list(type="syn-obj", cat="DP", case="nom")
tRole1.tdh <- list(type="syn-obj", cat="DP", case="nom")
p.match.vp <- list(type="pic-obj", agent="", theme="")
den <- list(type="syn-obj", cat="DP", case="acc", name="empty-den") # retrieve the predicted accusative DP
vater <- list(type="syn-obj", cat="DP", case="acc")
tRole2.a <- list(type="syn-obj", cat="DP", case="acc") # note: case marking only for correct retrieval and NOT for theta role assignment
tRole2.b <- list(type="syn-obj", cat="DP", case="acc")
tRole2.tdh <- list(type="syn-obj", cat="DP", case="acc")
p.match.np2 <- list(type="pic-obj", agent="", theme="")
p.match.end <- list(type="pic-obj", agent="", theme="")

ret.steps[[1,1]]=empty
ret.steps[[2,1]]=der
ret.steps[[3,1]]=sohn
ret.steps[[4,1]]=p.match.np1
ret.steps[[5,1]]=faengt
ret.steps[[6,1]]=tRole1.a
ret.steps[[7,1]]=tRole1.b
ret.steps[[8,1]]=tRole1.tdh
ret.steps[[9,1]]=p.match.vp
ret.steps[[10,1]]=den
ret.steps[[11,1]]=vater
ret.steps[[12,1]]=tRole2.a
ret.steps[[13,1]]=tRole2.b
ret.steps[[14,1]]=tRole2.tdh
ret.steps[[15,1]]=p.match.np2
ret.steps[[16,1]]=p.match.end


## -- LHS steps --
# The LHS of the production rule that has to be satisfied
# mainly the constraints on the retrieval buffer contents ("harvesting").
# It's the condition that has to be satisfied before carrying
# out the creation step.

lhs.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
der <- list(type="syn-obj", cat="DP")
sohn <- list(type="syn-obj", cat="DP")
p.match.np1 <- list(type="pic-obj")
faengt <- list(type="syn-obj", cat="CP")
tRole1.a <- list(type="syn-obj", cat="DP")
tRole1.b <- list(type="syn-obj", cat="DP")
tRole1.tdh <- list(type="syn-obj", cat="DP")
p.match.vp <- list(type="pic-obj")
den <- list(type="syn-obj", cat="DP")
vater <- list(type="syn-obj", cat="DP")
tRole2.a <- list(type="syn-obj", cat="DP")
tRole2.b <- list(type="syn-obj", cat="DP")
tRole2.tdh <- list(type="syn-obj", cat="DP")
p.match.np2 <- list(type="pic-obj")
p.match.end <- list(type="pic-obj")

lhs.steps[[1,1]]=empty
lhs.steps[[2,1]]=der
lhs.steps[[3,1]]=sohn
lhs.steps[[4,1]]=p.match.np1
lhs.steps[[5,1]]=faengt
lhs.steps[[6,1]]=tRole1.a
lhs.steps[[7,1]]=tRole1.b
lhs.steps[[8,1]]=tRole1.tdh
lhs.steps[[9,1]]=p.match.vp
lhs.steps[[10,1]]=den
lhs.steps[[11,1]]=vater
lhs.steps[[12,1]]=tRole2.a
lhs.steps[[13,1]]=tRole2.b
lhs.steps[[14,1]]=tRole2.tdh
lhs.steps[[15,1]]=p.match.np2
lhs.steps[[16,1]]=p.match.end


## -- Creation steps --
#Der				[type=syn-obj, cat=DP, case=nom], [type=syn-obj, cat=CP]
#Sohn			[type=syn-obj, cat=NP]

# 1. VP
vp.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", cat="VP", name="v-phrase", spec="t_s")
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

vp.steps[[1,1]]=empty
vp.steps[[2,1]]=der
vp.steps[[3,1]]=sohn
vp.steps[[4,1]]=p.match.np1
vp.steps[[5,1]]=faengt
vp.steps[[6,1]]=tRole1.a
vp.steps[[7,1]]=tRole1.b
vp.steps[[8,1]]=tRole1.tdh
vp.steps[[9,1]]=p.match.vp
vp.steps[[10,1]]=den
vp.steps[[11,1]]=vater
vp.steps[[12,1]]=tRole2.a
vp.steps[[13,1]]=tRole2.b
vp.steps[[14,1]]=tRole2.tdh
vp.steps[[15,1]]=p.match.np2
vp.steps[[16,1]]=p.match.end


# 2. NP
np.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
der <- list(NULL)
sohn <- list(type="syn-obj", name="sohn", cat="NP")
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(type="syn-obj", name="vater", cat="NP")
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

np.steps[[1,1]]=empty
np.steps[[2,1]]=der
np.steps[[3,1]]=sohn
np.steps[[4,1]]=p.match.np1
np.steps[[5,1]]=faengt
np.steps[[6,1]]=tRole1.a
np.steps[[7,1]]=tRole1.b
np.steps[[8,1]]=tRole1.tdh
np.steps[[9,1]]=p.match.vp
np.steps[[10,1]]=den
np.steps[[11,1]]=vater
np.steps[[12,1]]=tRole2.a
np.steps[[13,1]]=tRole2.b
np.steps[[14,1]]=tRole2.tdh
np.steps[[15,1]]=p.match.np2
np.steps[[16,1]]=p.match.end


# 3. DP
dp.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", name="empty-der", cat="DP", case="nom", trace.ind="t_s")
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(type="syn-obj", name="empty-den", cat="DP", case="acc") # prediction of the upcoming accusative DP
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

dp.steps[[1,1]]=empty
dp.steps[[2,1]]=der
dp.steps[[3,1]]=sohn
dp.steps[[4,1]]=p.match.np1
dp.steps[[5,1]]=faengt
dp.steps[[6,1]]=tRole1.a
dp.steps[[7,1]]=tRole1.b
dp.steps[[8,1]]=tRole1.tdh
dp.steps[[9,1]]=p.match.vp
dp.steps[[10,1]]=den
dp.steps[[11,1]]=vater
dp.steps[[12,1]]=tRole2.a
dp.steps[[13,1]]=tRole2.b
dp.steps[[14,1]]=tRole2.tdh
dp.steps[[15,1]]=p.match.np2
dp.steps[[16,1]]=p.match.end


# 4. IP
ip.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", cat="IP", name="infl-phrase", comp="VP-buff", spec="t_s")
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

ip.steps[[1,1]]=empty
ip.steps[[2,1]]=der
ip.steps[[3,1]]=sohn
ip.steps[[4,1]]=p.match.np1
ip.steps[[5,1]]=faengt
ip.steps[[6,1]]=tRole1.a
ip.steps[[7,1]]=tRole1.b
ip.steps[[8,1]]=tRole1.tdh
ip.steps[[9,1]]=p.match.vp
ip.steps[[10,1]]=den
ip.steps[[11,1]]=vater
ip.steps[[12,1]]=tRole2.a
ip.steps[[13,1]]=tRole2.b
ip.steps[[14,1]]=tRole2.tdh
ip.steps[[15,1]]=p.match.np2
ip.steps[[16,1]]=p.match.end


# 5. CP
cp.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", cat="CP", name="c-phrase", comp="IP-buff", spec="DP-buff")
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

cp.steps[[1,1]]=empty
cp.steps[[2,1]]=der
cp.steps[[3,1]]=sohn
cp.steps[[4,1]]=p.match.np1
cp.steps[[5,1]]=faengt
cp.steps[[6,1]]=tRole1.a
cp.steps[[7,1]]=tRole1.b
cp.steps[[8,1]]=tRole1.tdh
cp.steps[[9,1]]=p.match.vp
cp.steps[[10,1]]=den
cp.steps[[11,1]]=vater
cp.steps[[12,1]]=tRole2.a
cp.steps[[13,1]]=tRole2.b
cp.steps[[14,1]]=tRole2.tdh
cp.steps[[15,1]]=p.match.np2
cp.steps[[16,1]]=p.match.end


# 6. PP
pp.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

pp.steps[[1,1]]=empty
pp.steps[[2,1]]=der
pp.steps[[3,1]]=sohn
pp.steps[[4,1]]=p.match.np1
pp.steps[[5,1]]=faengt
pp.steps[[6,1]]=tRole1.a
pp.steps[[7,1]]=tRole1.b
pp.steps[[8,1]]=tRole1.tdh
pp.steps[[9,1]]=p.match.vp
pp.steps[[10,1]]=den
pp.steps[[11,1]]=vater
pp.steps[[12,1]]=tRole2.a
pp.steps[[13,1]]=tRole2.b
pp.steps[[14,1]]=tRole2.tdh
pp.steps[[15,1]]=p.match.np2
pp.steps[[16,1]]=p.match.end


# 7. AdjP
adjp.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
der <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
den <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

adjp.steps[[1,1]]=empty
adjp.steps[[2,1]]=der
adjp.steps[[3,1]]=sohn
adjp.steps[[4,1]]=p.match.np1
adjp.steps[[5,1]]=faengt
adjp.steps[[6,1]]=tRole1.a
adjp.steps[[7,1]]=tRole1.b
adjp.steps[[8,1]]=tRole1.tdh
adjp.steps[[9,1]]=p.match.vp
adjp.steps[[10,1]]=den
adjp.steps[[11,1]]=vater
adjp.steps[[12,1]]=tRole2.a
adjp.steps[[13,1]]=tRole2.b
adjp.steps[[14,1]]=tRole2.tdh
adjp.steps[[15,1]]=p.match.np2
adjp.steps[[16,1]]=p.match.end


## -- Utility values for steps --
# util.steps[*,1] = stage no.
# util.steps[*,2] = utility value of the step

util.steps = array(, c(steps,2))

empty <- c(1,0)
der <- c(2,0)
sohn <- c(3,0)
p.match.np1 <- c(4,0)
faengt <- c(5,0)
tRole1.a <- c(6,0)
tRole1.b <- c(6,0)
tRole1.tdh <- c(6,1)
p.match.vp <- c(7,0)
den <- c(8,0)
vater <- c(9,0)
tRole2.a <- c(10,0)
tRole2.b <- c(10,0)
tRole2.tdh <- c(10,1)
p.match.np2 <- c(11,0)
p.match.end <- c(12,0)

util.steps[1,]=empty
util.steps[2,]=der
util.steps[3,]=sohn
util.steps[4,]=p.match.np1
util.steps[5,]=faengt
util.steps[6,]=tRole1.a
util.steps[7,]=tRole1.b
util.steps[8,]=tRole1.tdh
util.steps[9,]=p.match.vp
util.steps[10,]=den
util.steps[11,]=vater
util.steps[12,]=tRole2.a
util.steps[13,]=tRole2.b
util.steps[14,]=tRole2.tdh
util.steps[15,]=p.match.np2
util.steps[16,]=p.match.end

## -- input stages
input.stages = c("empty", "der", "sohn", "pic-match-np1", "faengt", "tRole1", "pic-match-vp", "den", "vater", "tRole2", "pic-match-np2", "pic-match-end")
prods.names = c("empty", "der", "sohn", "p.match.np1", "faengt", "tRole1.a", "tRole1.b", "tRole1.tdh", "p.match.vp", "den", "vater", "tRole2.a", "tRole2.b", "tRole2.tdh", "p.match.np2", "p.match.end")

