
#-------------------------------------------------
#
# Model of Hanne, Sekerina, Vasishth, Burchert & De Bleser 2010
# Sentence: Den Sohn faengt der Vater (cond 2, SVO)
#
# 
# Author: Umesh Patil (umesh.patil@gmail.com)
#
#-------------------------------------------------


## -- Goal chunk --
goal.chunk <- list(type="comprehend-sentence", name="", agent="", theme="")
# 'name' missing


## -- Picture chunks --
pic.chunks = array(list(NULL), c(2,1))

# ctime: creation time
# npres: no. of presentations

pic1 <- list(type="pic-obj", ctime=0, npres=1, name="pic-canon", agent="Sohn-lex", theme="Vater-lex")
pic2 <- list(type="pic-obj", ctime=0, npres=1, name="pic-noncanon", agent="Vater-lex", theme="Sohn-lex")

#pic.chunks[[1,1]]=pic1
#pic.chunks[[2,1]]=pic2



## -- Goal buffer modification steps --

goal.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(theme="Sohn-lex")
tRole1.b <- list(agent="Sohn-lex")
tRole1.tdh <- list(agent="Sohn-lex")
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(agent="Vater-lex")
tRole2.b <- list(theme="Vater-lex")
tRole2.tdh.a <- list(agent="Vater-lex", theme="Sohn-lex")
tRole2.tdh.b <- list(theme="Vater-lex")
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

goal.steps[[1,1]]=empty
goal.steps[[2,1]]=den
goal.steps[[3,1]]=ovs.cost
goal.steps[[4,1]]=sohn
goal.steps[[5,1]]=p.match.np1
goal.steps[[6,1]]=faengt
goal.steps[[7,1]]=tRole1.a
goal.steps[[8,1]]=tRole1.b
goal.steps[[9,1]]=tRole1.tdh
goal.steps[[10,1]]=p.match.vp
goal.steps[[11,1]]=der
goal.steps[[12,1]]=vater
goal.steps[[13,1]]=tRole2.a
goal.steps[[14,1]]=tRole2.b
goal.steps[[15,1]]=tRole2.tdh.a
goal.steps[[16,1]]=tRole2.tdh.b
goal.steps[[17,1]]=p.match.np2
goal.steps[[18,1]]=p.match.end


## -- Retrieval steps --
ret.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
den <- list(type="syn-obj", cat="CP")
ovs.cost <- list(type="syn-obj", cat="VP") # ret. VP for deleting the trace 't_s' in the specVP
sohn <- list(type="syn-obj", cat="DP", case="acc")
p.match.np1 <- list(type="pic-obj", agent="", theme="")
faengt <- list(type="syn-obj", cat="CP")
tRole1.a <- list(type="syn-obj", cat="DP", case="acc") # note: case marking only for correct retrieval and NOT for theta role assignment; theta roles are assigned using the trace information
tRole1.b <- list(type="syn-obj", cat="DP", case="acc")
tRole1.tdh <- list(type="syn-obj", cat="DP", case="acc")
p.match.vp <- list(type="pic-obj", agent="", theme="")
der <- list(type="syn-obj", cat="DP", case="nom", name="empty-der") # 'name="empty-der"' here signifies that the head is empty (= retrieve that nominative DP which has an empty head)
vater <- list(type="syn-obj", cat="DP", case="nom")
tRole2.a <- list(type="syn-obj", cat="DP", case="nom") # note: case marking only for correct retrieval and NOT for theta role assignment
tRole2.b <- list(type="syn-obj", cat="DP", case="nom")
tRole2.tdh.a <- list(type="syn-obj", cat="DP", case="nom")
tRole2.tdh.b <- list(type="syn-obj", cat="DP", case="nom")
p.match.np2 <- list(type="pic-obj", agent="", theme="")
p.match.end <- list(type="pic-obj", agent="", theme="")

ret.steps[[1,1]]=empty
ret.steps[[2,1]]=den
ret.steps[[3,1]]=ovs.cost
ret.steps[[4,1]]=sohn
ret.steps[[5,1]]=p.match.np1
ret.steps[[6,1]]=faengt
ret.steps[[7,1]]=tRole1.a
ret.steps[[8,1]]=tRole1.b
ret.steps[[9,1]]=tRole1.tdh
ret.steps[[10,1]]=p.match.vp
ret.steps[[11,1]]=der
ret.steps[[12,1]]=vater
ret.steps[[13,1]]=tRole2.a
ret.steps[[14,1]]=tRole2.b
ret.steps[[15,1]]=tRole2.tdh.a
ret.steps[[16,1]]=tRole2.tdh.b
ret.steps[[17,1]]=p.match.np2
ret.steps[[18,1]]=p.match.end


## -- LHS steps --
# The LHS of the production rule that has to be satisfied
# mainly the constraints on the retrieval buffer contents.
# It's the condition that has to be satisfied before carrying
# out the creation step.

lhs.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
den <- list(type="syn-obj", cat="CP")
ovs.cost <- list(type="syn-obj", cat="VP")
sohn <- list(type="syn-obj", cat="DP")
p.match.np1 <- list(type="pic-obj")
faengt <- list(type="syn-obj", cat="CP")
tRole1.a <- list(type="syn-obj", cat="DP")
tRole1.b <- list(type="syn-obj", cat="DP")
tRole1.tdh <- list(type="syn-obj", cat="DP")
p.match.vp <- list(type="pic-obj")
der <- list(type="syn-obj", cat="DP")
vater <- list(type="syn-obj", cat="DP")
tRole2.a <- list(type="syn-obj", cat="DP")
tRole2.b <- list(type="syn-obj", cat="DP")
tRole2.tdh.a <- list(type="syn-obj", cat="DP")
tRole2.tdh.b <- list(type="syn-obj", cat="DP")
p.match.np2 <- list(type="pic-obj")
p.match.end <- list(type="pic-obj")

lhs.steps[[1,1]]=empty
lhs.steps[[2,1]]=den
lhs.steps[[3,1]]=ovs.cost
lhs.steps[[4,1]]=sohn
lhs.steps[[5,1]]=p.match.np1
lhs.steps[[6,1]]=faengt
lhs.steps[[7,1]]=tRole1.a
lhs.steps[[8,1]]=tRole1.b
lhs.steps[[9,1]]=tRole1.tdh
lhs.steps[[10,1]]=p.match.vp
lhs.steps[[11,1]]=der
lhs.steps[[12,1]]=vater
lhs.steps[[13,1]]=tRole2.a
lhs.steps[[14,1]]=tRole2.b
lhs.steps[[15,1]]=tRole2.tdh.a
lhs.steps[[16,1]]=tRole2.tdh.b
lhs.steps[[17,1]]=p.match.np2
lhs.steps[[18,1]]=p.match.end


## -- Creation steps --
#Der				[type=syn-obj, cat=DP, case=nom], [type=syn-obj, cat=CP]
#Sohn			[type=syn-obj, cat=NP]

# 1. VP
vp.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", cat="VP", name="v-phrase", spec="t_s")
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

vp.steps[[1,1]]=empty
vp.steps[[2,1]]=den
vp.steps[[3,1]]=ovs.cost
vp.steps[[4,1]]=sohn
vp.steps[[5,1]]=p.match.np1
vp.steps[[6,1]]=faengt
vp.steps[[7,1]]=tRole1.a
vp.steps[[8,1]]=tRole1.b
vp.steps[[9,1]]=tRole1.tdh
vp.steps[[10,1]]=p.match.vp
vp.steps[[11,1]]=der
vp.steps[[12,1]]=vater
vp.steps[[13,1]]=tRole2.a
vp.steps[[14,1]]=tRole2.b
vp.steps[[15,1]]=tRole2.tdh.a
vp.steps[[16,1]]=tRole2.tdh.b
vp.steps[[17,1]]=p.match.np2
vp.steps[[18,1]]=p.match.end


# 2. NP
np.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(type="syn-obj", name="sohn", cat="NP")
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(type="syn-obj", name="vater", cat="NP")
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

np.steps[[1,1]]=empty
np.steps[[2,1]]=den
np.steps[[3,1]]=ovs.cost
np.steps[[4,1]]=sohn
np.steps[[5,1]]=p.match.np1
np.steps[[6,1]]=faengt
np.steps[[7,1]]=tRole1.a
np.steps[[8,1]]=tRole1.b
np.steps[[9,1]]=tRole1.tdh
np.steps[[10,1]]=p.match.vp
np.steps[[11,1]]=der
np.steps[[12,1]]=vater
np.steps[[13,1]]=tRole2.a
np.steps[[14,1]]=tRole2.b
np.steps[[15,1]]=tRole2.tdh.a
np.steps[[16,1]]=tRole2.tdh.b
np.steps[[17,1]]=p.match.np2
np.steps[[18,1]]=p.match.end


# 3. DP
dp.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", name="empty-der", cat="DP", case="nom", trace.ind="t_s")
den <- list(type="syn-obj", name="den", cat="DP", case="acc", trace.ind="t_o")
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(type="syn-obj", name="empty-der", cat="DP", case="nom", trace.ind="t_s")
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

dp.steps[[1,1]]=empty
dp.steps[[2,1]]=den
dp.steps[[3,1]]=ovs.cost
dp.steps[[4,1]]=sohn
dp.steps[[5,1]]=p.match.np1
dp.steps[[6,1]]=faengt
dp.steps[[7,1]]=tRole1.a
dp.steps[[8,1]]=tRole1.b
dp.steps[[9,1]]=tRole1.tdh
dp.steps[[10,1]]=p.match.vp
dp.steps[[11,1]]=der
dp.steps[[12,1]]=vater
dp.steps[[13,1]]=tRole2.a
dp.steps[[14,1]]=tRole2.b
dp.steps[[15,1]]=tRole2.tdh.a
dp.steps[[16,1]]=tRole2.tdh.b
dp.steps[[17,1]]=p.match.np2
dp.steps[[18,1]]=p.match.end


# 4. IP
ip.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", cat="IP", name="infl-phrase", comp="VP-buff")
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

ip.steps[[1,1]]=empty
ip.steps[[2,1]]=den
ip.steps[[3,1]]=ovs.cost
ip.steps[[4,1]]=sohn
ip.steps[[5,1]]=p.match.np1
ip.steps[[6,1]]=faengt
ip.steps[[7,1]]=tRole1.a
ip.steps[[8,1]]=tRole1.b
ip.steps[[9,1]]=tRole1.tdh
ip.steps[[10,1]]=p.match.vp
ip.steps[[11,1]]=der
ip.steps[[12,1]]=vater
ip.steps[[13,1]]=tRole2.a
ip.steps[[14,1]]=tRole2.b
ip.steps[[15,1]]=tRole2.tdh.a
ip.steps[[16,1]]=tRole2.tdh.b
ip.steps[[17,1]]=p.match.np2
ip.steps[[18,1]]=p.match.end


# 5. CP
cp.steps = array(list(NULL), c(steps,1))

empty <- list(type="syn-obj", cat="CP", name="c-phrase", comp="IP-buff", spec="DP-buff")
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

cp.steps[[1,1]]=empty
cp.steps[[2,1]]=den
cp.steps[[3,1]]=ovs.cost
cp.steps[[4,1]]=sohn
cp.steps[[5,1]]=p.match.np1
cp.steps[[6,1]]=faengt
cp.steps[[7,1]]=tRole1.a
cp.steps[[8,1]]=tRole1.b
cp.steps[[9,1]]=tRole1.tdh
cp.steps[[10,1]]=p.match.vp
cp.steps[[11,1]]=der
cp.steps[[12,1]]=vater
cp.steps[[13,1]]=tRole2.a
cp.steps[[14,1]]=tRole2.b
cp.steps[[15,1]]=tRole2.tdh.a
cp.steps[[16,1]]=tRole2.tdh.b
cp.steps[[17,1]]=p.match.np2
cp.steps[[18,1]]=p.match.end


# 6. pp
pp.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

pp.steps[[1,1]]=empty
pp.steps[[2,1]]=den
pp.steps[[3,1]]=ovs.cost
pp.steps[[4,1]]=sohn
pp.steps[[5,1]]=p.match.np1
pp.steps[[6,1]]=faengt
pp.steps[[7,1]]=tRole1.a
pp.steps[[8,1]]=tRole1.b
pp.steps[[9,1]]=tRole1.tdh
pp.steps[[10,1]]=p.match.vp
pp.steps[[11,1]]=der
pp.steps[[12,1]]=vater
pp.steps[[13,1]]=tRole2.a
pp.steps[[14,1]]=tRole2.b
pp.steps[[15,1]]=tRole2.tdh.a
pp.steps[[16,1]]=tRole2.tdh.b
pp.steps[[17,1]]=p.match.np2
pp.steps[[18,1]]=p.match.end


# 7. adjp
adjp.steps = array(list(NULL), c(steps,1))

empty <- list(NULL)
den <- list(NULL)
ovs.cost <- list(NULL)
sohn <- list(NULL)
p.match.np1 <- list(NULL)
faengt <- list(NULL)
tRole1.a <- list(NULL)
tRole1.b <- list(NULL)
tRole1.tdh <- list(NULL)
p.match.vp <- list(NULL)
der <- list(NULL)
vater <- list(NULL)
tRole2.a <- list(NULL)
tRole2.b <- list(NULL)
tRole2.tdh.a <- list(NULL)
tRole2.tdh.b <- list(NULL)
p.match.np2 <- list(NULL)
p.match.end <- list(NULL)

adjp.steps[[1,1]]=empty
adjp.steps[[2,1]]=den
adjp.steps[[3,1]]=ovs.cost
adjp.steps[[4,1]]=sohn
adjp.steps[[5,1]]=p.match.np1
adjp.steps[[6,1]]=faengt
adjp.steps[[7,1]]=tRole1.a
adjp.steps[[8,1]]=tRole1.b
adjp.steps[[9,1]]=tRole1.tdh
adjp.steps[[10,1]]=p.match.vp
adjp.steps[[11,1]]=der
adjp.steps[[12,1]]=vater
adjp.steps[[13,1]]=tRole2.a
adjp.steps[[14,1]]=tRole2.b
adjp.steps[[15,1]]=tRole2.tdh.a
adjp.steps[[16,1]]=tRole2.tdh.b
adjp.steps[[17,1]]=p.match.np2
adjp.steps[[18,1]]=p.match.end



## -- Utility values for steps --
# util.steps[*,1] = stage no.
# util.steps[*,2] = utility value of the step

util.steps = array(, c(steps,2))

empty <- c(1,0)
den <- c(2,0)
ovs.cost <- c(3,0)
sohn <- c(4,0)
p.match.np1 <- c(5,0)
faengt <- c(6,0)
tRole1.a <- c(7,0)
tRole1.b <- c(7,0)
tRole1.tdh <- c(7,1)
p.match.vp <- c(8,0)
der <- c(9,0)
vater <- c(10,0)
tRole2.a <- c(11,0)
tRole2.b <- c(11,0)
tRole2.tdh.a <- c(11,0.5)
tRole2.tdh.b <- c(11,0.5)
p.match.np2 <- c(12,0)
p.match.end <- c(13,0)


util.steps[1,]=empty
util.steps[2,]=den
util.steps[3,]=ovs.cost
util.steps[4,]=sohn
util.steps[5,]=p.match.np1
util.steps[6,]=faengt
util.steps[7,]=tRole1.a
util.steps[8,]=tRole1.b
util.steps[9,]=tRole1.tdh
util.steps[10,]=p.match.vp
util.steps[11,]=der
util.steps[12,]=vater
util.steps[13,]=tRole2.a
util.steps[14,]=tRole2.b
util.steps[15,]=tRole2.tdh.a
util.steps[16,]=tRole2.tdh.b
util.steps[17,]=p.match.np2
util.steps[18,]=p.match.end

## -- input stages
input.stages = c("empty", "den", "ovs.cost", "sohn", "pic-match-np1", "faengt", "tRole1", "pic-match-vp", "der", "vater", "tRole2", "pic-match-np2", "pic-match-end")
prods.names = c("empty", "den", "ovs.cost", "sohn", "p.match.np1", "faengt", "tRole1.a", "tRole1.b", "tRole1.tdh", "p.match.vp", "der", "vater", "tRole2.a", "tRole2.b", "tRole2.tdh.a", "tRole2.tdh.b", "p.match.np2", "p.match.end")


