# 
# Author: Umesh Patil (umesh.patil@gmail.com)
#

source("../R-functions/se.R")

#  data preparation	---------------

dt.cont = read.csv("controls-nw-id.csv", header=TRUE)
dt.iwa = read.csv("iwas-nw-id.csv", header=TRUE)

# controls' summarized/averaged data 
dt.cont.sum = 
  merge(
    merge(
      ddply(subset(dt.cont, cond=="SVO", select=c("subj", "ACC")), .(subj), summarise, ACC.SVO=mean(ACC, na.rm=TRUE)*100),
      ddply(subset(dt.cont, cond=="OVS", select=c("subj", "ACC")), .(subj), summarise, ACC.OVS=mean(ACC, na.rm=TRUE)*100),
    ),
    merge(
      merge(
        ddply(subset(dt.cont, cond=="SVO" & ACC==1, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.SVO.cor=mean(RT, na.rm=TRUE), 
              RT.SVO.cor.se=se(RT)
        ),
        ddply(subset(dt.cont, cond=="OVS" & ACC==1, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.OVS.cor=mean(RT, na.rm=TRUE), 
              RT.OVS.cor.se=se(RT)
        ),
        all=TRUE
      ),
      merge(
        ddply(subset(dt.cont, cond=="SVO" & ACC==0, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.SVO.incor=mean(RT, na.rm=TRUE), 
              RT.SVO.incor.se=se(RT)
        ),
        ddply(subset(dt.cont, cond=="OVS" & ACC==0, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.OVS.incor=mean(RT, na.rm=TRUE), 
              RT.OVS.incor.se=se(RT)
        ),
        all=TRUE
      )	,
      all=TRUE
    )
  )



# iwas' summarized/averaged data 
dt.iwa.sum = 
  merge(
    merge(
      ddply(subset(dt.iwa, cond=="SVO", select=c("subj", "ACC")), .(subj), summarise, ACC.SVO=mean(ACC, na.rm=TRUE)*100),
      ddply(subset(dt.iwa, cond=="OVS", select=c("subj", "ACC")), .(subj), summarise, ACC.OVS=mean(ACC, na.rm=TRUE)*100),
    ),
    merge(
      merge(
        ddply(subset(dt.iwa, cond=="SVO" & ACC==1, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.SVO.cor=mean(RT, na.rm=TRUE), 
              RT.SVO.cor.se=se(RT)
        ),
        ddply(subset(dt.iwa, cond=="OVS" & ACC==1, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.OVS.cor=mean(RT, na.rm=TRUE), 
              RT.OVS.cor.se=se(RT)
        ),
        all=TRUE
      ),
      merge(
        ddply(subset(dt.iwa, cond=="SVO" & ACC==0, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.SVO.incor=mean(RT, na.rm=TRUE), 
              RT.SVO.incor.se=se(RT)
        ),
        ddply(subset(dt.iwa, cond=="OVS" & ACC==0, 
                     select=c("subj", "RT")), .(subj), 
              summarise, 
              RT.OVS.incor=mean(RT, na.rm=TRUE), 
              RT.OVS.incor.se=se(RT)
        ),
        all=TRUE
      ),
      all=TRUE
    )
  )


write.table(dt.cont.sum, "dt-cont-sum.txt", quote=FALSE, row.names=FALSE)
write.table(dt.iwa.sum, "dt-iwa-sum.txt", quote=FALSE, row.names=FALSE)


