#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


#! start fresh
rm(list=ls())

#! load global variables and functions
source("global.R")
source("R-functions/se.R")
source("R-functions/percent.R")
source("R-functions/rmsd.R")

# library(plyr)
# library(lattice)

#! read in the simulations file with 'simNo' no. of parameter combinations
dataFile = "R-ACT-R/predictions/cont.txt"
dt.sims = read.table(file=dataFile, header=TRUE)

#! no. of simulations
simNo = dim(dt.sims)[1]

dt.cont.sum = read.table("data/dt-cont-sum.txt", header=TRUE)
dt.iwa.sum  = read.table("data/dt-iwa-sum.txt", header=TRUE)


#########################################################################################
# Compute NRMSD value for each prediction & each subject
#########################################################################################

# Controls  -------------------

#! read the predictions file
pred.cont = subset(dt.sims, 
				select=c("act.noise", "prod.tm", "prod.noise", "acc.can", "acc.noncan", 
						"rt.can.cor", "rt.noncan.cor", "rt.can.incor", "rt.noncan.incor")
				)

#! compute NRMSD for accuracies & RTs for each subject & parameter value combination
for(sbj in 1:length(dt.cont.sum$subj)){
  cnames = colnames(pred.cont)
  pred.dim = dim(pred.cont)[2]
  pred.cont[,(pred.dim+1):(pred.dim+3)] = NA
  colnames(pred.cont) = c(cnames, paste(as.character(dt.cont.sum$subj[sbj]), ".ACC", sep=""), 
                          paste(as.character(dt.cont.sum$subj[sbj]), ".RT", sep=""),
                          paste(as.character(dt.cont.sum$subj[sbj]), ".both", sep=""))
  
  for(sim in 1:simNo){
    nrmsd.acc = nrmsd(dt.cont.sum[sbj,2:3], pred.cont[sim,4:5])
    
    # consider RTs only for the correct predictions since controls are mostly accurate
    # and RTs for incorrect predictions are mostly NA's
    nrmsd.rt = nrmsd(dt.cont.sum[sbj,c(4,6)], pred.cont[sim,6:7])
    
    
    # combine the two nrmsd values by taking a mean of the two NRMSDs:
    
    # option-1: if one of them is an NA then
    # the mean is the other NRMSD value; if both are NA then the mean is NA.
    nrmsd.both = ifelse(is.na(nrmsd.acc), 
                        ifelse(is.na(nrmsd.rt), NA, nrmsd.rt), 
                        ifelse(is.na(nrmsd.rt), nrmsd.acc, mean(c(nrmsd.acc, nrmsd.rt)))
    )
    # option-2: mean value of the two NRMSDs provided both are not NAs; else the mean is NA
    #     nrmsd.both = ifelse(is.na(nrmsd.acc) || is.na(nrmsd.rt), 
    #                         NA, mean(c(nrmsd.acc, nrmsd.rt))
    #                         )
    
    pred.cont[sim, dim(pred.cont)[2]-2] = nrmsd.acc
    pred.cont[sim, dim(pred.cont)[2]-1] = nrmsd.rt
    pred.cont[sim, dim(pred.cont)[2]]   = nrmsd.both
  }
}


# IWAs    -------------------
# REM:
# . decide if having NA's in the predictions for RTs is OK or not for considering 
#   in the selection of the M3 parameters. One position cd b that if there's any NA, exclude that for M3


#! read the predictions file
pred.iwa = subset(dt.sims, 
                  select=c("act.noise", "prod.tm", "prod.noise", "acc.can", "acc.noncan", 
                           "rt.can.cor", "rt.noncan.cor", "rt.can.incor", "rt.noncan.incor")
)

#! compute NRMSD for accuracies & RTs for each subject & parameter value combination
for(sbj in 1:length(dt.iwa.sum$subj)){
  cnames = colnames(pred.iwa)
  pred.dim = dim(pred.iwa)[2]
  pred.iwa[,(pred.dim+1):(pred.dim+3)] = NA
  colnames(pred.iwa) = c(cnames, paste(as.character(dt.iwa.sum$subj[sbj]), ".ACC", sep=""), 
                         paste(as.character(dt.iwa.sum$subj[sbj]), ".RT", sep=""),
                         paste(as.character(dt.iwa.sum$subj[sbj]), ".both", sep=""))
  
  for(sim in 1:simNo){
    nrmsd.acc = nrmsd(dt.iwa.sum[sbj,2:3], pred.iwa[sim,4:5])
    nrmsd.rt = nrmsd(dt.iwa.sum[sbj,c(4,6,8,10)], pred.iwa[sim,6:9])


# combine the two nrmsd values by taking a mean of the two NRMSDs:

# option-1: if one of them is an NA then
# the mean is the other NRMSD value; if both are NA then the mean is NA.
    nrmsd.both = ifelse(is.na(nrmsd.acc), 
                          ifelse(is.na(nrmsd.rt), NA, nrmsd.rt), 
                          ifelse(is.na(nrmsd.rt), nrmsd.acc, mean(c(nrmsd.acc, nrmsd.rt)))
                        )
# option-2: mean value of the two NRMSDs provided both are not NAs; else the mean is NA
#     nrmsd.both = ifelse(is.na(nrmsd.acc) || is.na(nrmsd.rt), 
#                         NA, mean(c(nrmsd.acc, nrmsd.rt))
#                         )

    pred.iwa[sim, dim(pred.iwa)[2]-2] = nrmsd.acc
    pred.iwa[sim, dim(pred.iwa)[2]-1] = nrmsd.rt
    pred.iwa[sim, dim(pred.iwa)[2]]   = nrmsd.both
  }
}


########################################################
#	Parameter selection procedure
########################################################

#
# 1.
# Fix the parameters for controls, TDH-1 & TDH-2
# and also one of the parameter for M1 & M2
#
# Parameters for controls have to be fixed so that M1 & M2
# fit only one of the two parameters. Also, TDH models should
# use the same fixed set of parameters used for controls
#

prod.noise.select = 0.01
prod.tm.select    = 0.02
act.noise.select  = 0.3

nsub = dim(dt.iwa.sum)[1] # no. of subjects (aphasics or controls)


# 2.
# Aphasics: select params for the best fit for ACC & RTs
# method 2:
# 1. estimate parameters based on the NRMSD values that are averaged from 
#    the NRMSD values for accuracy and response time
# 2. estimate parameters for M3 instead of using M1 & M2 parameters

# Best parameters for model M1
param.m1 = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.m1) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

pred.m1 = subset(pred.iwa, act.noise == act.noise.select & 
                   prod.noise == prod.noise.select)

j=0
for(i in 3:9 * 3){
	j=j+1
	pred.rt = subset(pred.m1, pred.m1[,i+3]==min(pred.m1[,i+3]))

  #! if more than one parameter combination satifies the condition of min(nrmsd)
  #! then simply select the 1st parameter combination
  if(dim(pred.rt)[1] > 1){
    print(paste("find-ind-params.R: more than one best parameter combination for", substr(colnames(pred.m1)[i+1], 1, 2), "in model M1", sep=" "))
    pred.rt = pred.rt[1, ]
  }

  param.m1[j,] = c(colnames(pred.m1)[i+1], act.noise.select, pred.rt$prod.noise, 
							pred.rt$prod.tm, pred.rt[,i+1], pred.rt[,i+2], pred.rt[,i+3])
	}

pred.param.m1 = merge(param.m1, dt.sims, by=c("act.noise", "prod.noise","prod.tm"))

write.table(pred.param.m1, 
            paste("R-ACT-R/predictions/pred.param.m1-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
            )



# Best parameters for model M2
param.m2 = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.m2) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

pred.m2 = subset(pred.iwa, act.noise == act.noise.select & 
					 prod.tm == prod.tm.select)

j=0
for(i in 3:9 * 3){
  j=j+1
	pred.acc = subset(pred.m2, pred.m2[,i+3]==min(pred.m2[,i+3]))
  
  #! if more than one parameter combination satifies the condition of min(nrmsd)
  #! then simply select the 1st parameter combination
  if(dim(pred.acc)[1] > 1){
    print(paste("find-ind-params.R: more than one best parameter combination for", substr(colnames(pred.m2)[i+1], 1, 2), "in model M2", sep=" "))
    pred.acc = pred.acc[1, ]
  }
  
  param.m2[j,] = c(colnames(pred.m2)[i+2], act.noise.select, pred.acc$prod.noise, 
							pred.acc$prod.tm, pred.acc[,i+1], pred.acc[,i+2], pred.acc[,i+3])
	}

pred.param.m2 = merge(param.m2, dt.sims, by=c("act.noise", "prod.noise","prod.tm"))

write.table(pred.param.m2, 
            paste("R-ACT-R/predictions/pred.param.m2-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
            )


# Best parameters for model M3
param.m3 = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.m3) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

pred.m3 = subset(pred.iwa, act.noise == act.noise.select)

j=0
for(i in 3:9 * 3){
  j=j+1
  pred.both = subset(pred.m3, pred.m3[,i+3]==min(pred.m3[,i+3]))
  
  #! if more than one parameter combination satifies the condition of min(nrmsd)
  #! then simply select the 1st parameter combination
  if(dim(pred.both)[1] > 1){
    print(paste("find-ind-params.R: more than one best parameter combination for", substr(colnames(pred.m3)[i+1], 1, 2), "in model M3", sep=" "))
    pred.both = pred.both[1, ]
  }
  
  param.m3[j,] = c(colnames(pred.m3)[i+3], act.noise.select, pred.both$prod.noise, 
                   pred.both$prod.tm, pred.both[,i+1], pred.both[,i+2], pred.both[,i+3])
}

pred.param.m3 = merge(param.m3, dt.sims, by=c("act.noise", "prod.noise","prod.tm"))

write.table(pred.param.m3, 
            paste("R-ACT-R/predictions/pred.param.m3-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
            )


# Sanity check!
# 
# tmp.m1 = pred.param.m1[order(pred.param.m1$subj),][,2:7]
# tmp.m1$nrmsd.av = (as.numeric(tmp.m1$nrmsd.acc) + as.numeric(tmp.m1$nrmsd.rt))/2
# 
# tmp.m2 = pred.param.m2[order(pred.param.m2$subj),][,2:7]
# tmp.m2$nrmsd.av = (as.numeric(tmp.m2$nrmsd.acc) + as.numeric(tmp.m2$nrmsd.rt))/2
# 
# tmp.m3 = pred.param.m3[order(pred.param.m3$subj),][,2:7]
# tmp.m3$nrmsd.av = (as.numeric(tmp.m3$nrmsd.acc) + as.numeric(tmp.m3$nrmsd.rt))/2
# 



#! Best parameters for individual controls
#! this is only for comparing the degree of 
#! two impairments in aphasics with lack of 
#! variation among controls
param.cont.ind = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.cont.ind) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

pred.cont.ind = subset(pred.cont, act.noise == act.noise.select)

j=0
for(i in 3:9 * 3){
  j=j+1
  pred.both = subset(pred.cont.ind, pred.cont.ind[,i+3]==min(pred.cont.ind[,i+3]))
  
  #! if more than one parameter combination satifies the condition of min(nrmsd)
  #! then simply select the 1st parameter combination
  if(dim(pred.both)[1] > 1){
    print(paste("find-ind-params.R: more than one best parameter combination for control", substr(colnames(pred.cont.ind)[i+1], 1, 2), sep=" "))
    pred.both = pred.both[1, ]
  }
  
  param.cont.ind[j,] = c(colnames(pred.cont.ind)[i+3], act.noise.select, pred.both$prod.noise, 
                         pred.both$prod.tm, pred.both[,i+1], pred.both[,i+2], pred.both[,i+3])
}

pred.param.cont.ind = merge(param.cont.ind, dt.sims, by=c("act.noise", "prod.noise","prod.tm"))

write.table(pred.param.cont.ind, 
            paste("R-ACT-R/predictions/pred.param.cont.ind-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
)


#! get the predicted ACC & RT's for individual controls (no param estimation)
param.cont = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.cont) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

#! there's already a data.frame named 'pred.cont'
pred.control = subset(pred.cont, 
                   prod.noise == prod.noise.select 
                   & prod.tm == prod.tm.select
                   & act.noise == act.noise.select 
                   )

j=0
for(i in 3:9 * 3){
  j=j+1
  param.cont[j,] = c(colnames(pred.control)[i+3], act.noise.select, pred.control$prod.noise, 
                     pred.control$prod.tm, pred.control[,i+1], pred.control[,i+2], pred.control[,i+3])
}

pred.param.cont = merge(param.cont, dt.sims, by=c("act.noise", "prod.noise","prod.tm"))

write.table(pred.param.cont, 
            paste("R-ACT-R/predictions/pred.fixParam.cont-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
            )


#
# TDH
#
#! read the predictions file
pred.tdh1 = subset(read.table(file="R-ACT-R/predictions/tdhv1.txt", header=TRUE), 
                   act.noise==act.noise.select,
                   select=c("act.noise", "prod.tm", "prod.noise", "acc.can", "acc.noncan", 
                            "rt.can.cor", "rt.noncan.cor", "rt.can.incor", "rt.noncan.incor")
                   )

#! compute NRMSD for accuracies & RTs for each subject & parameter value combination
for(sbj in 1:length(dt.iwa.sum$subj)){
  cnames = colnames(pred.tdh1)
  pred.dim = dim(pred.tdh1)[2]
  pred.tdh1[,(pred.dim+1):(pred.dim+3)] = NA
  colnames(pred.tdh1) = c(cnames, paste(as.character(dt.iwa.sum$subj[sbj]), ".ACC", sep=""), 
                          paste(as.character(dt.iwa.sum$subj[sbj]), ".RT", sep=""),
                          paste(as.character(dt.iwa.sum$subj[sbj]), ".both", sep=""))
  
  sim = 1
    nrmsd.acc = nrmsd(dt.iwa.sum[sbj,2:3], pred.tdh1[sim,4:5])
    nrmsd.rt = nrmsd(dt.iwa.sum[sbj,c(4,6,8,10)], pred.tdh1[sim,6:9])
    
    
    # combine the two nrmsd values by taking a mean of the two NRMSDs:
    
    # option-1: if one of them is an NA then
    # the mean is the other NRMSD value; if both are NA then the mean is NA.
    nrmsd.both = ifelse(is.na(nrmsd.acc), 
                        ifelse(is.na(nrmsd.rt), NA, nrmsd.rt), 
                        ifelse(is.na(nrmsd.rt), nrmsd.acc, mean(c(nrmsd.acc, nrmsd.rt)))
    )
    # option-2: mean value of the two NRMSDs provided both are not NAs; else the mean is NA
    #     nrmsd.both = ifelse(is.na(nrmsd.acc) || is.na(nrmsd.rt), 
    #                         NA, mean(c(nrmsd.acc, nrmsd.rt))
    #                         )
    
    pred.tdh1[sim, dim(pred.tdh1)[2]-2] = nrmsd.acc
    pred.tdh1[sim, dim(pred.tdh1)[2]-1] = nrmsd.rt
    pred.tdh1[sim, dim(pred.tdh1)[2]]   = nrmsd.both
  
}


#! get the predicted ACC & RT's for individual patients (no param estimation)
param.tdh1 = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.tdh1) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

j=0
for(i in 3:9 * 3){
  j=j+1
  param.tdh1[j,] = c(colnames(pred.tdh1)[i+3], act.noise.select, pred.tdh1$prod.noise, 
                     pred.tdh1$prod.tm, pred.tdh1[,i+1], pred.tdh1[,i+2], pred.tdh1[,i+3])
}

pred.param.tdh1 = merge(param.tdh1, 
                        read.table(file="R-ACT-R/predictions/tdhv1.txt", header=TRUE), 
                        by=c("act.noise", "prod.noise","prod.tm")
                        )
write.table(pred.param.tdh1, 
            paste("R-ACT-R/predictions/pred.fixParam.tdhv1-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
            )


#! NRMSD for TDH-2 predictions
pred.tdh2 = subset(read.table(file="R-ACT-R/predictions/tdhv2.txt", header=TRUE), 
                   act.noise==act.noise.select,
                   select=c("act.noise", "prod.tm", "prod.noise", "acc.can", "acc.noncan", 
                            "rt.can.cor", "rt.noncan.cor", "rt.can.incor", "rt.noncan.incor")
)

#! compute NRMSD for accuracies & RTs for each subject & parameter value combination
for(sbj in 1:length(dt.iwa.sum$subj)){
  cnames = colnames(pred.tdh2)
  pred.dim = dim(pred.tdh2)[2]
  pred.tdh2[,(pred.dim+1):(pred.dim+3)] = NA
  colnames(pred.tdh2) = c(cnames, paste(as.character(dt.iwa.sum$subj[sbj]), ".ACC", sep=""), 
                          paste(as.character(dt.iwa.sum$subj[sbj]), ".RT", sep=""),
                          paste(as.character(dt.iwa.sum$subj[sbj]), ".both", sep=""))
  
  sim = 1
  nrmsd.acc = nrmsd(dt.iwa.sum[sbj,2:3], pred.tdh2[sim,4:5])
  nrmsd.rt = nrmsd(dt.iwa.sum[sbj,c(4,6,8,10)], pred.tdh2[sim,6:9])
  
  
  # combine the two nrmsd values by taking a mean of the two NRMSDs:
  
  # option-1: if one of them is an NA then
  # the mean is the other NRMSD value; if both are NA then the mean is NA.
  nrmsd.both = ifelse(is.na(nrmsd.acc), 
                      ifelse(is.na(nrmsd.rt), NA, nrmsd.rt), 
                      ifelse(is.na(nrmsd.rt), nrmsd.acc, mean(c(nrmsd.acc, nrmsd.rt)))
  )
  # option-2: mean value of the two NRMSDs provided both are not NAs; else the mean is NA
  #     nrmsd.both = ifelse(is.na(nrmsd.acc) || is.na(nrmsd.rt), 
  #                         NA, mean(c(nrmsd.acc, nrmsd.rt))
  #                         )
  
  pred.tdh2[sim, dim(pred.tdh2)[2]-2] = nrmsd.acc
  pred.tdh2[sim, dim(pred.tdh2)[2]-1] = nrmsd.rt
  pred.tdh2[sim, dim(pred.tdh2)[2]]   = nrmsd.both
  
}


#! get the predicted ACC & RT's for individual patients (no param estimation)
param.tdh2 = as.data.frame(matrix(nrow=nsub, ncol=7))
colnames(param.tdh2) = c("subj", "act.noise", "prod.noise","prod.tm", "nrmsd.acc", "nrmsd.rt", "nrmsd.both")

j=0
for(i in 3:9 * 3){
  j=j+1
  param.tdh2[j,] = c(colnames(pred.tdh2)[i+3], act.noise.select, pred.tdh2$prod.noise, 
                     pred.tdh2$prod.tm, pred.tdh2[,i+1], pred.tdh2[,i+2], pred.tdh2[,i+3])
}

pred.param.tdh2 = merge(param.tdh2, 
                        read.table(file="R-ACT-R/predictions/tdhv2.txt", header=TRUE), 
                        by=c("act.noise", "prod.noise","prod.tm")
                        )

write.table(pred.param.tdh2, 
            paste("R-ACT-R/predictions/pred.fixParam.tdhv2-n", act.noise.select, ".txt", sep=""), 
            quote=FALSE, row.names=FALSE
            )

