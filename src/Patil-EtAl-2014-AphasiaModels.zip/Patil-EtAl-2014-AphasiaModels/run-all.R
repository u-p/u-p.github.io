#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


#! divert the messages to a file
sink("messages.txt")

#! load global declarations
source("global.R")

#! run the models
source("run-aphasia-model.R")

#! find individual paramters
source("find-ind-params.R")

#! compute various NRMSDs and write them to files
source("nrmsds.R")

#! generate plots
source("plots.R")

#! generate tables
source("tables.R")

sink(file=NULL)

