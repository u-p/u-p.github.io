
source(paste(HOME, "R-functions/se.R", sep="/"))
source(paste(HOME, "R-functions/percent.R", sep="/"))


#! Read model output

extractPredictions <- function(nruns=1, dir=NULL){
  # nruns = no. of runs = no. of output files of each type
  
  dt = as.data.frame(matrix(nrow=nruns, ncol=69))
  
  colnames(dt) = c(
    "goal.act", "mas", "decay", "act.noise", "latency", "ret.thr", "match.sc", "max.sim", "max.diff", "prod.tm", "prod.noise",
    #					"mas", "decay", "act.noise", "latency", "ret.thr", "match.sc", "max.sim", "max.diff", "prod.tm", "prod.noise",
    
    "rt.can.cor", "rt.noncan.cor", "rt.can.incor", "rt.noncan.incor", 
    "se.can.cor", "se.noncan.cor", "se.can.incor", "se.noncan.incor", 
    
    "acc.can", "acc.noncan", 
    
    "em.can.np1", "em.can.vp", "em.can.np2", "em.can.sil", 
    "em.noncan.np1", "em.noncan.vp", "em.noncan.np2", "em.noncan.sil", 
    "em.can.cor.np1", "em.can.cor.vp", "em.can.cor.np2", "em.can.cor.sil", 
    "em.noncan.cor.np1", "em.noncan.cor.vp", "em.noncan.cor.np2", "em.noncan.cor.sil", 
    "em.can.incor.np1", "em.can.incor.vp", "em.can.incor.np2", "em.can.incor.sil", 
    "em.noncan.incor.np1", "em.noncan.incor.vp", "em.noncan.incor.np2", "em.noncan.incor.sil",
    
    "act.diff.can.np1", "act.diff.can.vp", "act.diff.can.np2", "act.diff.can.sil", 
    "act.diff.noncan.np1", "act.diff.noncan.vp", "act.diff.noncan.np2", "act.diff.noncan.sil", 
    "act.diff.can.cor.np1", "act.diff.can.cor.vp", "act.diff.can.cor.np2", "act.diff.can.cor.sil", 
    "act.diff.noncan.cor.np1", "act.diff.noncan.cor.vp", "act.diff.noncan.cor.np2", "act.diff.noncan.cor.sil", 
    "act.diff.can.incor.np1", "act.diff.can.incor.vp", "act.diff.can.incor.np2", "act.diff.can.incor.sil", 
    "act.diff.noncan.incor.np1", "act.diff.noncan.incor.vp", "act.diff.noncan.incor.np2", "act.diff.noncan.incor.sil"
  )
  
  
  for(i in c(1:nruns)){
    
    #-- cond 1 - SVO
    
    times.1 = read.table(paste(dir, "/cond-1/ret-times-", i, ".txt", sep=""), header=TRUE)
    retrieves.1 = read.table(paste(dir, "/cond-1/retrievals-", i, ".txt", sep=""), header=TRUE)
    act.piccan.1 = read.table(paste(dir, "/cond-1/piccan-act-", i, ".txt", sep=""), header=TRUE)
    act.picnoncan.1 = read.table(paste(dir, "/cond-1/picnoncan-act-", i, ".txt", sep=""), header=TRUE)
    
    #-- cond 2 - OVS
    times.2 = read.table(paste(dir, "/cond-2/ret-times-", i, ".txt", sep=""), header=TRUE)
    retrieves.2 = read.table(paste(dir, "/cond-2/retrievals-", i, ".txt", sep=""), header=TRUE)
    act.piccan.2 = read.table(paste(dir, "/cond-2/piccan-act-", i, ".txt", sep=""), header=TRUE)
    act.picnoncan.2 = read.table(paste(dir, "/cond-2/picnoncan-act-", i, ".txt", sep=""), header=TRUE)
    
    params = read.table(paste(dir, "/cond-1/params-", i, ".txt", sep=""), header=TRUE)
    
    
    times.1 = subset(times.1, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))*1000    # convert retrieval times to milliseconds
    retrieves.1 = subset(retrieves.1, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))
    act.piccan.1 = subset(act.piccan.1, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))
    act.picnoncan.1 = subset(act.picnoncan.1, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))
    act.diff.1 = act.piccan.1 - act.picnoncan.1
    
    dt.1 = cbind(retrieves.1, times.1, act.diff.1)
    colnames(dt.1) = c("ret.np1", "ret.vp", "ret.np2", "ret.end", "tm.np1", "tm.vp", "tm.np2", "tm.end", "act.np1", "act.vp", "act.np2", "act.end")
    dt.1$acc = ifelse(dt.1$ret.end=="pic-canon", 1, ifelse(dt.1$ret.end=="pic-noncanon", 0, NA))
    
    
    times.2 = subset(times.2, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))*1000    # convert retrieval times to milliseconds
    retrieves.2 = subset(retrieves.2, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))
    act.piccan.2 = subset(act.piccan.2, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))
    act.picnoncan.2 = subset(act.picnoncan.2, select=c(pic.match.np1, pic.match.vp, pic.match.np2, pic.match.end))
    act.diff.2 = act.picnoncan.2 - act.piccan.2
    
    dt.2 = cbind(retrieves.2, times.2, act.diff.2)
    colnames(dt.2) = c("ret.np1", "ret.vp", "ret.np2", "ret.end", "tm.np1", "tm.vp", "tm.np2", "tm.end", "act.np1", "act.vp", "act.np2", "act.end")
    dt.2$acc = ifelse(dt.2$ret.end=="pic-noncanon", 1, ifelse(dt.2$ret.end=="pic-canon", 0, NA))
    
    
    # -- 1. Picture verification RTs --
    RT = t(c(mean(subset(dt.1, acc==1)$tm.end),
             mean(subset(dt.2, acc==1)$tm.end),
             mean(subset(dt.1, acc==0)$tm.end),
             mean(subset(dt.2, acc==0)$tm.end)
    ))
    
    SE = t(c(se(subset(dt.1, acc==1)$tm.end),
             se(subset(dt.2, acc==1)$tm.end),
             se(subset(dt.1, acc==0)$tm.end),
             se(subset(dt.2, acc==0)$tm.end)
    ))
    
    
    #-- 2. Accuracy --
    acc <- t(c(
      percent(dim(dt.1[dt.1$acc==1,])[[1]], dim(dt.1[dt.1$acc==0,])[[1]], dim(dt.1)[[1]]),
      percent(dim(dt.2[dt.2$acc==1,])[[1]], dim(dt.2[dt.2$acc==0,])[[1]], dim(dt.2)[[1]])
    ))
    
    
    
    # -- 3a. Eye-movements (retrievals) --
    em.1 = c(50, 
             ##!
             ##	percent(table(dt.1$ret.np1)[[1]], table(dt.1$ret.np1)[[2]], sum(table(dt.1$ret.np1))),
             ## above doesn't work if there are zero 'pic-canon' or 'pic-noncanon
             #
             ##	percent(dim(dt.1[dt.1$ret.np1=="pic-canon",])[[1]], dim(dt.1[dt.1$ret.np1=="pic-noncanon",])[[1]], dim(dt.1)[[1]])
             ##	above doesn't work due to NA's. They get counted as well!
             #
             percent(dim(subset(dt.1, ret.np1=="pic-canon"))[1], dim(subset(dt.1, ret.np1=="pic-noncanon"))[1], dim(dt.1)[[1]]),
             percent(dim(subset(dt.1, ret.vp=="pic-canon"))[1], dim(subset(dt.1, ret.vp=="pic-noncanon"))[1], dim(dt.1)[[1]]),
             percent(dim(subset(dt.1, ret.np2=="pic-canon"))[1], dim(subset(dt.1, ret.np2=="pic-noncanon"))[1], dim(dt.1)[[1]])
    )
    
    em.2 = c(50, 
             percent(dim(subset(dt.2, ret.np1=="pic-noncanon"))[1], dim(subset(dt.2, ret.np1=="pic-canon"))[1], dim(dt.2)[[1]]),
             percent(dim(subset(dt.2, ret.vp=="pic-noncanon"))[1], dim(subset(dt.2, ret.vp=="pic-canon"))[1], dim(dt.2)[[1]]),
             percent(dim(subset(dt.2, ret.np2=="pic-noncanon"))[1], dim(subset(dt.2, ret.np2=="pic-canon"))[1], dim(dt.2)[[1]])
    )
    
    
    cor.1 = subset(dt.1, acc==1)
    cor.2 = subset(dt.2, acc==1)
    
    em.1.cor = c(50, 
                 percent(dim(subset(cor.1, ret.np1=="pic-canon"))[1], dim(subset(cor.1, ret.np1=="pic-noncanon"))[1], dim(cor.1)[[1]]),
                 percent(dim(subset(cor.1, ret.vp=="pic-canon"))[1], dim(subset(cor.1, ret.vp=="pic-noncanon"))[1], dim(cor.1)[[1]]),
                 percent(dim(subset(cor.1, ret.np2=="pic-canon"))[1], dim(subset(cor.1, ret.np2=="pic-noncanon"))[1], dim(cor.1)[[1]])
    )
    
    em.2.cor = c(50, 
                 percent(dim(subset(cor.2, ret.np1=="pic-noncanon"))[1], dim(subset(cor.2, ret.np1=="pic-canon"))[1], dim(cor.2)[[1]]),
                 percent(dim(subset(cor.2, ret.vp=="pic-noncanon"))[1], dim(subset(cor.2, ret.vp=="pic-canon"))[1], dim(cor.2)[[1]]),
                 percent(dim(subset(cor.2, ret.np2=="pic-noncanon"))[1], dim(subset(cor.2, ret.np2=="pic-canon"))[1], dim(cor.2)[[1]])
    )
    
    
    incor.1 = subset(dt.1, acc==0)
    incor.2 = subset(dt.2, acc==0)
    
    em.1.incor = c(50, 
                   percent(dim(subset(incor.1, ret.np1=="pic-canon"))[1], dim(subset(incor.1, ret.np1=="pic-noncanon"))[1], dim(incor.1)[[1]]),
                   percent(dim(subset(incor.1, ret.vp=="pic-canon"))[1], dim(subset(incor.1, ret.vp=="pic-noncanon"))[1], dim(incor.1)[[1]]),
                   percent(dim(subset(incor.1, ret.np2=="pic-canon"))[1], dim(subset(incor.1, ret.np2=="pic-noncanon"))[1], dim(incor.1)[[1]])
    )
    
    em.2.incor = c(50, 
                   percent(dim(subset(incor.2, ret.np1=="pic-noncanon"))[1], dim(subset(incor.2, ret.np1=="pic-canon"))[1], dim(incor.2)[[1]]),
                   percent(dim(subset(incor.2, ret.vp=="pic-noncanon"))[1], dim(subset(incor.2, ret.vp=="pic-canon"))[1], dim(incor.2)[[1]]),
                   percent(dim(subset(incor.2, ret.np2=="pic-noncanon"))[1], dim(subset(incor.2, ret.np2=="pic-canon"))[1], dim(incor.2)[[1]])
    )
    
    em.pred = t(c(em.1, em.2, em.1.cor, em.2.cor, em.1.incor, em.2.incor))
    
    
    # -- 3b. Eye-movements (activation differences) --
    
    act.1 = c(0, mean(dt.1$act.np1), mean(dt.1$act.vp), mean(dt.1$act.np2))
    act.2 = c(0, mean(dt.2$act.np1), mean(dt.2$act.vp), mean(dt.2$act.np2))
    act.1.cor = c(0, mean(cor.1$act.np1), mean(cor.1$act.vp), mean(cor.1$act.np2))
    act.2.cor = c(0, mean(cor.2$act.np1), mean(cor.2$act.vp), mean(cor.2$act.np2))
    act.1.incor = c(0, mean(incor.1$act.np1), mean(incor.1$act.vp), mean(incor.1$act.np2))
    act.2.incor = c(0, mean(incor.2$act.np1), mean(incor.2$act.vp), mean(incor.2$act.np2))
    
    act.pred = t(c(act.1, act.2, act.1.cor, act.2.cor, act.1.incor, act.2.incor))
    
    
    dt[i, ] = cbind(params, RT, SE, acc, em.pred, act.pred)
  }
  
  return(dt)
  
}

