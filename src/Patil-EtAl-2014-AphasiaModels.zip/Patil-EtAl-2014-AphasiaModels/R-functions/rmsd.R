

#	RMSD	---------------------

rmsd <-function(d, predictions) {
    sd <- (predictions-d)^2
    return(sqrt(sum(sd)/length(sd)))
   }

#------------------------------------




#	Normalized RMSD	-------------

nrmsd <-function(d, predictions) {
	range = max(d, na.rm=TRUE) - 
		min(d, na.rm=TRUE) # range of observed values
   return(rmsd(d, predictions)/range)
   }

#------------------------------------

