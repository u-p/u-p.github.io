
## returns percentages after dividing the difference (no retrievals) EQUALLY into the two numbers
percent <- function(num1, num2, max){
  diff = max-(num1+num2)
  num1=num1+(diff/2)
  num2=num2+(diff/2)
  
  return(num1*100/sum(max))
}

