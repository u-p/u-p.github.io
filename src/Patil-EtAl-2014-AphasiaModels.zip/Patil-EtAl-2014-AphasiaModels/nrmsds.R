#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


###################################################
# compute various NRMSDs and write them to files
###################################################


#! start fresh
rm(list=ls())

library("reshape2")

source("R-functions/rmsd.R")


#! load data
acc.dt = read.table("data/Accuracy-data.txt", header=TRUE)
em.dt = read.table("data/em-data.txt", header=TRUE)
rt.dt = read.table("data/RT-data.txt", header=TRUE)

em.dt$acc = ifelse(em.dt$acc == 0, "incor", "cor")


# #! get the (aggregated) EM data in the required format (to combine it with the predictions)
# tp1 = dcast(em.dt[,1:4], subj~cond+acc, value='np1')
# colnames(tp1) = c("subj", "can.cor.np1", "can.incor.np1", "noncan.cor.np1", "noncan.incor.np1")
# 
# tp2 = dcast(em.dt[,c(1:3,5)], subj~cond+acc)
# colnames(tp2) = c("subj", "can.cor.vp", "can.incor.vp", "noncan.cor.vp", "noncan.incor.vp")
# 
# tp3 = dcast(em.dt[,c(1:3,6)], subj~cond+acc)
# colnames(tp3) = c("subj", "can.cor.np2", "can.incor.np2", "noncan.cor.np2", "noncan.incor.np2")
# 
# tp4 = dcast(em.dt[,c(1:3,7)], subj~cond+acc)
# colnames(tp4) = c("subj", "can.cor.silence", "can.incor.silence", "noncan.cor.silence", "noncan.incor.silence")
# 
# em.data = merge(merge(merge(tp1, tp2), tp3), tp4)
# 
# em.data = em.data[,c(1,2,6,10,14, 4,8,12,16, 3,7,11,15, 5,9,13,17)]
# write.table(em.data, file="data/EM/data.txt")


#! load model predictions
cont = read.table("R-ACT-R/predictions/pred.fixParam.cont-n0.3.txt", header=TRUE)
tdhv1 = read.table("R-ACT-R/predictions/pred.fixParam.tdhv1-n0.3.txt", header=TRUE)
tdhv2 = read.table("R-ACT-R/predictions/pred.fixParam.tdhv2-n0.3.txt", header=TRUE)
m1 = read.table("R-ACT-R/predictions/pred.param.m1-n0.3.txt", header=TRUE)
m2 = read.table("R-ACT-R/predictions/pred.param.m2-n0.3.txt", header=TRUE)
m3 = read.table("R-ACT-R/predictions/pred.param.m3-n0.3.txt", header=TRUE)

#! get rid of extra characters in the subject ids
cont$subj = substr(cont$subj, 1,2)
tdhv1$subj = substr(tdhv1$subj, 1,2)
tdhv2$subj = substr(tdhv2$subj, 1,2)
m1$subj = substr(m1$subj, 1,2)
m2$subj = substr(m2$subj, 1,2)
m3$subj = substr(m3$subj, 1,2)

# #! write models' EM predictions for each model to files (umm..why?)
# write.table(cont[,c(4,58:73)], file="data/EM/mod-cont.txt")
# write.table(tdhv1[,c(4,58:73)], file="data/EM/mod-tdhv1.txt")
# write.table(tdhv2[,c(4,58:73)], file="data/EM/mod-tdhv2.txt")
# write.table(m1[,c(4,58:73)], file="data/EM/mod-m1.txt")
# write.table(m2[,c(4,58:73)], file="data/EM/mod-m2.txt")
# write.table(m3[,c(4,58:73)], file="data/EM/mod-m3.txt")


#----- individual NRMSD for eye movements

#! data (aggregated EMs for each participant)
em.ind = read.csv("data/em-ind-iwa-nw-id.csv", header=TRUE)[,1:5]
colnames(em.ind) = c(colnames(em.ind)[1:4], "perc")


#! models

# m1
tmp = melt(m1[,c(4,58:73)], value.name = "m1")
tmp$acc  = c("cor")
tmp$cond = c("can")
tmp$roi  = c("sil")

tmp[grep("np1", tmp$variable),]$roi = "np1"
tmp[grep("np2", tmp$variable),]$roi = "np2"
tmp[grep("vp", tmp$variable),]$roi = "vp"
tmp[grep("noncan", tmp$variable),]$cond = "noncan"
tmp[grep("incor", tmp$variable),]$acc = "incor"

em.pred = tmp[,c(1,3:6)]

em = merge(em.pred, em.ind)


# m2
tmp = melt(m2[,c(4,58:73)], value.name = "m2")
tmp$acc  = c("cor")
tmp$cond = c("can")
tmp$roi  = c("sil")

tmp[grep("np1", tmp$variable),]$roi = "np1"
tmp[grep("np2", tmp$variable),]$roi = "np2"
tmp[grep("vp", tmp$variable),]$roi = "vp"
tmp[grep("noncan", tmp$variable),]$cond = "noncan"
tmp[grep("incor", tmp$variable),]$acc = "incor"

em.pred = tmp[,c(1,3:6)]

em = merge(em.pred, em)


# m3
tmp = melt(m3[,c(4,58:73)], value.name = "m3")
tmp$acc  = c("cor")
tmp$cond = c("can")
tmp$roi  = c("sil")

tmp[grep("np1", tmp$variable),]$roi = "np1"
tmp[grep("np2", tmp$variable),]$roi = "np2"
tmp[grep("vp", tmp$variable),]$roi = "vp"
tmp[grep("noncan", tmp$variable),]$cond = "noncan"
tmp[grep("incor", tmp$variable),]$acc = "incor"

em.pred = tmp[,c(1,3:6)]

em = merge(em.pred, em)


# tdhv1
tmp = melt(tdhv1[,c(4,58:73)], value.name = "tdhv1")
tmp$acc  = c("cor")
tmp$cond = c("can")
tmp$roi  = c("sil")

tmp[grep("np1", tmp$variable),]$roi = "np1"
tmp[grep("np2", tmp$variable),]$roi = "np2"
tmp[grep("vp", tmp$variable),]$roi = "vp"
tmp[grep("noncan", tmp$variable),]$cond = "noncan"
tmp[grep("incor", tmp$variable),]$acc = "incor"

em.pred = tmp[,c(1,3:6)]

em = merge(em.pred, em)


# tdhv2
tmp = melt(tdhv2[,c(4,58:73)], value.name = "tdhv2")
tmp$acc  = c("cor")
tmp$cond = c("can")
tmp$roi  = c("sil")

tmp[grep("np1", tmp$variable),]$roi = "np1"
tmp[grep("np2", tmp$variable),]$roi = "np2"
tmp[grep("vp", tmp$variable),]$roi = "vp"
tmp[grep("noncan", tmp$variable),]$cond = "noncan"
tmp[grep("incor", tmp$variable),]$acc = "incor"

em.pred = tmp[,c(1,3:6)]

em = merge(em.pred, em)

write.table(em, "R-ACT-R/predictions/em-ind-pred.txt", quote=FALSE, row.names=FALSE)


#! calculate individual NRMSDS
subj = unique(em$subj)
acc = unique(em$acc)
cond = unique(em$cond)

em.nrmsd.ind = as.data.frame(matrix(nrow=length(subj)*4, ncol=8))
colnames(em.nrmsd.ind) = c("subj", "cond", "acc", "tdhv1", "tdhv2", "m1", "m2", "m3")

i=0
for(s in subj){
  for(c in cond){
    for(a in acc){
      i=i+1
      em.sub = subset(em, subj==s & acc==a & cond==c)
      em.nrmsd.ind[i,] = c(s, c, a, 
                           round(nrmsd(em.sub$perc, em.sub$tdhv1), 3),
                           round(nrmsd(em.sub$perc, em.sub$tdhv2), 3),
                           round(nrmsd(em.sub$perc, em.sub$m1), 3),
                           round(nrmsd(em.sub$perc, em.sub$m2), 3),
                           round(nrmsd(em.sub$perc, em.sub$m3), 3)
      )
    }
  }
}


write.table(em.nrmsd.ind, "R-ACT-R/predictions/em-ind-nrmsd.txt", quote=FALSE, row.names=FALSE)

# subset(em.nrmsd.ind, cond=="can" & acc=="cor")
# subset(em.nrmsd.ind, cond=="noncan" & acc=="cor")
# 
# subset(em.nrmsd.ind, cond=="can" & acc=="incor")
# subset(em.nrmsd.ind, cond=="noncan" & acc=="incor")


#! NRMSD for aggregate data

# Eye fixations

# aggregated EM data
em.dt.tmp = em.dt
colnames(em.dt.tmp)<-c("cond", "subj", "acc", "np1", "vp", "np2", "sil")
# 
# colnames(em.dt.tmp)<-c(colnames(em.dt.tmp)[1:length(colnames(em.dt))-1],"sil")
# 
em.agg.tmp = melt(em.dt.tmp)
em.agg.tmp = subset(em.agg.tmp, subj=="iwa", select=c("cond", "acc", "variable", "value"))
colnames(em.agg.tmp) = c("cond", "acc", "roi", "perc")

#! aggregated predictions
tmp.t1 = data.frame(paste(em$acc, em$cond, em$roi, sep="."), em$tdhv1)
colnames(tmp.t1) = c("cond", "tdhv1")

tmp.t2 = data.frame(paste(em$acc, em$cond, em$roi, sep="."), em$tdhv2)
colnames(tmp.t2) = c("cond", "tdhv2")

tmp.m1 = data.frame(paste(em$acc, em$cond, em$roi, sep="."), em$m1)
colnames(tmp.m1) = c("cond", "m1")

tmp.m2 = data.frame(paste(em$acc, em$cond, em$roi, sep="."), em$m2)
colnames(tmp.m2) = c("cond", "m2")

tmp.m3 = data.frame(paste(em$acc, em$cond, em$roi, sep="."), em$m3)
colnames(tmp.m3) = c("cond", "m3")

tmp = rbind(cbind("tdhv1", t(with(tmp.t1, tapply(tdhv1,cond,mean,na.rm=TRUE)))),
            cbind("tdhv2", t(with(tmp.t2, tapply(tdhv2,cond,mean,na.rm=TRUE)))),
            cbind("m1", t(with(tmp.m1, tapply(m1,cond,mean,na.rm=TRUE)))),
            cbind("m2", t(with(tmp.m2, tapply(m2,cond,mean,na.rm=TRUE)))),
            cbind("m3", t(with(tmp.m3, tapply(m3,cond,mean,na.rm=TRUE))))
)

colnames(tmp)[1] = "model"

tmp2 = as.data.frame(cbind(colnames(tmp)[2:ncol(tmp)], t(tmp[,2:ncol(tmp)])))
colnames(tmp2) = c("cn", tmp[,1])

tmp2$acc  = c("cor")
tmp2$cond = c("can")
tmp2$roi  = c("sil")

tmp2[grep("np1", tmp2$cn),]$roi = "np1"
tmp2[grep("np2", tmp2$cn),]$roi = "np2"
tmp2[grep("vp", tmp2$cn),]$roi = "vp"
tmp2[grep("noncan", tmp2$cn),]$cond = "noncan"
tmp2[grep("incor", tmp2$cn),]$acc = "incor"

tmp2 = tmp2[,2:ncol(tmp2)]

em.agg = merge(tmp2, em.agg.tmp)

# convert factors into numbers
em.agg$tdhv1 = as.numeric(as.character(em.agg$tdhv1))
em.agg$tdhv2 = as.numeric(as.character(em.agg$tdhv2))
em.agg$m1 = as.numeric(as.character(em.agg$m1))
em.agg$m2 = as.numeric(as.character(em.agg$m2))
em.agg$m3 = as.numeric(as.character(em.agg$m3))

#! calculate NRMSDs
acc = unique(em.agg$acc)
cond = unique(em.agg$cond)

em.nrmsd = as.data.frame(matrix(nrow=4, ncol=7))
colnames(em.nrmsd) = c("cond", "acc", "tdhv1", "tdhv2", "m1", "m2", "m3")

i=0
for(c in cond){
  for(a in acc){
    i=i+1
    em.sub = subset(em.agg, acc==a & cond==c)
    em.nrmsd[i,] = c(c, a, 
                     round(nrmsd(em.sub$perc, em.sub$tdhv1), 3),
                     round(nrmsd(em.sub$perc, em.sub$tdhv2), 3),
                     round(nrmsd(em.sub$perc, em.sub$m1), 3),
                     round(nrmsd(em.sub$perc, em.sub$m2), 3),
                     round(nrmsd(em.sub$perc, em.sub$m3), 3)
    )
  }
}

write.table(em.nrmsd, "R-ACT-R/predictions/em-nrmsd.txt", quote=FALSE, row.names=FALSE)



# Aggregated accuracy NMRSD

#! aggregated data
acc.dt.tmp = subset(acc.dt, subj=="iwa", select=c("cond", "acc"))


#! aggregated predictions
acc.pred = data.frame(cbind(c(mean(tdhv1$acc.can), mean(tdhv1$acc.noncan)),
                            c(mean(tdhv2$acc.can), mean(tdhv2$acc.noncan)),
                            c(mean(m1$acc.can), mean(m1$acc.noncan)),
                            c(mean(m2$acc.can), mean(m2$acc.noncan)),
                            c(mean(m3$acc.can), mean(m3$acc.noncan))
)
)

colnames(acc.pred) = c("tdhv1", "tdhv2", "m1", "m2", "m3")

acc.pred$cond=c("can", "noncan")

acc.agg = merge(acc.dt.tmp, acc.pred)

acc.nrmsd = as.data.frame(matrix(nrow=1, ncol=5))
colnames(acc.nrmsd) = c("tdhv1", "tdhv2", "m1", "m2", "m3")

acc.nrmsd[1,] = c(round(nrmsd(acc.agg$acc, acc.agg$tdhv1), 3),
                  round(nrmsd(acc.agg$acc, acc.agg$tdhv2), 3),
                  round(nrmsd(acc.agg$acc, acc.agg$m1), 3),
                  round(nrmsd(acc.agg$acc, acc.agg$m2), 3),
                  round(nrmsd(acc.agg$acc, acc.agg$m3), 3)
)

write.table(acc.nrmsd, "R-ACT-R/predictions/acc-nrmsd.txt", quote=FALSE, row.names=FALSE)


# Aggregated RTs NMRSD

#! aggregated data
rt.dt.tmp = subset(rt.dt, subj=="iwa", select=c("cond", "acc", "RT"))
rt.dt.tmp$acc = ifelse(rt.dt.tmp$acc==1, "cor", "incor")

#! aggregated predictions
rt.pred = data.frame(cbind(c(mean(tdhv1$rt.can.cor), mean(tdhv1$rt.noncan.cor), mean(tdhv1$rt.can.incor), mean(tdhv1$rt.noncan.incor)),
                           c(mean(tdhv2$rt.can.cor), mean(tdhv2$rt.noncan.cor), mean(tdhv2$rt.can.incor), mean(tdhv2$rt.noncan.incor)),
                           c(mean(m1$rt.can.cor), mean(m1$rt.noncan.cor), mean(m1$rt.can.incor), mean(m1$rt.noncan.incor)),
                           c(mean(m2$rt.can.cor), mean(m2$rt.noncan.cor), mean(m2$rt.can.incor), mean(m2$rt.noncan.incor)),
                           c(mean(m3$rt.can.cor), mean(m3$rt.noncan.cor), mean(m3$rt.can.incor), mean(m3$rt.noncan.incor))
)
)

rt.pred[,c(6,7)] = merge(c("can", "noncan"), c("cor", "incor"))
colnames(rt.pred) = c("tdhv1", "tdhv2", "m1", "m2", "m3", "cond", "acc")


rt.agg = merge(rt.dt.tmp, rt.pred)

rt.nrmsd = as.data.frame(matrix(nrow=1, ncol=5))
colnames(rt.nrmsd) = c("tdhv1", "tdhv2", "m1", "m2", "m3")

rt.nrmsd[1,] = c(round(nrmsd(rt.agg$RT, rt.agg$tdhv1), 3),
                 round(nrmsd(rt.agg$RT, rt.agg$tdhv2), 3),
                 round(nrmsd(rt.agg$RT, rt.agg$m1), 3),
                 round(nrmsd(rt.agg$RT, rt.agg$m2), 3),
                 round(nrmsd(rt.agg$RT, rt.agg$m3), 3)
)

write.table(rt.nrmsd, "R-ACT-R/predictions/rt-nrmsd.txt", quote=FALSE, row.names=FALSE)


