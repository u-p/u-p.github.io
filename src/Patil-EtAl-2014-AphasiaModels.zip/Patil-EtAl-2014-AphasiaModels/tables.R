#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


########################################################
# Tables for the paper
########################################################


#! start fresh
rm(list=ls())


#! load model predictions
cont = read.table("R-ACT-R/predictions/pred.fixParam.cont-n0.3.txt", header=TRUE)
tdhv1 = read.table("R-ACT-R/predictions/pred.fixParam.tdhv1-n0.3.txt", header=TRUE)
tdhv2 = read.table("R-ACT-R/predictions/pred.fixParam.tdhv2-n0.3.txt", header=TRUE)
m1 = read.table("R-ACT-R/predictions/pred.param.m1-n0.3.txt", header=TRUE)
m2 = read.table("R-ACT-R/predictions/pred.param.m2-n0.3.txt", header=TRUE)
m3 = read.table("R-ACT-R/predictions/pred.param.m3-n0.3.txt", header=TRUE)

#! get rid of extra characters in the subject ids
cont$subj = substr(cont$subj, 1,2)
tdhv1$subj = substr(tdhv1$subj, 1,2)
tdhv2$subj = substr(tdhv2$subj, 1,2)
m1$subj = substr(m1$subj, 1,2)
m2$subj = substr(m2$subj, 1,2)
m3$subj = substr(m3$subj, 1,2)


c.names1 = c("Participant", "&", "TDH-1", "&", "TDH-2", "&", "M1", "&", "M2", "&", "M3", "\\\\")

# NRMSDs for accuracies (5 models of IWAs)

nrmsd.acc = data.frame(cbind(as.character(c(m1[order(m1$subj),4], "mean")), "&", 
                              round(c(tdhv1[order(tdhv1$subj),c(5)], mean(tdhv1[,c(5)])), 2), "&",
                              round(c(tdhv2[order(tdhv2$subj),c(5)], mean(tdhv2[,c(5)])), 2), "&",
                              round(c(m1[order(m1$subj),c(5)], mean(m1[,c(5)])), 2), "&", 
                              round(c(m2[order(m2$subj),c(5)], mean(m2[,c(5)])), 2), "&", 
                              round(c(m3[order(m3$subj),c(5)], mean(m3[,c(5)])), 2), "\\\\"
                             )
                       )

colnames(nrmsd.acc) = c.names1

write.table(nrmsd.acc, "tables/nrmsd-acc-ind.txt", quote=FALSE, row.names=FALSE)


# NRMSDs for RTs (5 models of IWAs)
# nrmsd.rt = data.frame(cbind(as.character(m1[order(m1$subj),4]), "&", 
#                        round(tdhv1[order(tdhv1$subj),c(6)], 2), "&", 
#                        round(tdhv2[order(tdhv2$subj),c(6)], 2), "&", 
#                        round(m1[order(m1$subj),c(6)], 2), "&", 
#                        round(m2[order(m2$subj),c(6)], 2), "&", 
#                        round(m3[order(m3$subj),c(6)], 2), "\\\\"
#                       )
#                     )

nrmsd.rt = data.frame(cbind(as.character(c(m1[order(m1$subj),4], "mean")), "&", 
                            round(c(tdhv1[order(tdhv1$subj),c(6)], mean(tdhv1[,c(6)])), 2), "&",
                            round(c(tdhv2[order(tdhv2$subj),c(6)], mean(tdhv2[,c(6)])), 2), "&",
                            round(c(m1[order(m1$subj),c(6)], mean(m1[,c(6)])), 2), "&", 
                            round(c(m2[order(m2$subj),c(6)], mean(m2[,c(6)])), 2), "&", 
                            round(c(m3[order(m3$subj),c(6)], mean(m3[,c(6)])), 2), "\\\\"
)
)

colnames(nrmsd.rt) = c.names1

write.table(nrmsd.rt, "tables/nrmsd-rt-ind.txt", quote=FALSE, row.names=FALSE)


# NRMSDs for both measures combined (5 models of IWAs)
# nrmsd.both = data.frame(cbind(as.character(m1[order(m1$subj),4]), "&", 
#                        round(tdhv1[order(tdhv1$subj),c(7)], 2), "&", 
#                        round(tdhv2[order(tdhv2$subj),c(7)], 2), "&", 
#                        round(m1[order(m1$subj),c(7)], 2), "&", 
#                        round(m2[order(m2$subj),c(7)], 2), "&", 
#                        round(m3[order(m3$subj),c(7)], 2), "\\\\"
#                        )
#                     )

nrmsd.both = data.frame(cbind(as.character(c(m1[order(m1$subj),4], "mean")), "&", 
                            round(c(tdhv1[order(tdhv1$subj),c(7)], mean(tdhv1[,c(7)])), 2), "&",
                            round(c(tdhv2[order(tdhv2$subj),c(7)], mean(tdhv2[,c(7)])), 2), "&",
                            round(c(m1[order(m1$subj),c(7)], mean(m1[,c(7)])), 2), "&", 
                            round(c(m2[order(m2$subj),c(7)], mean(m2[,c(7)])), 2), "&", 
                            round(c(m3[order(m3$subj),c(7)], mean(m3[,c(7)])), 2), "\\\\"
)
)

colnames(nrmsd.both) = c.names1

write.table(nrmsd.both, "tables/nrmsd-comb.txt", quote=FALSE, row.names=FALSE)


# NRMSDs for accuracies (controls)
c.names2 = c("Participant", "&", "Accuracy", "&", "RT", "\\\\")

nrmsd.cont = data.frame(cbind(as.character(cont[order(cont$subj),4]), "&", 
                       round(cont[order(cont$subj),c(5)], 1), "&", 
                       round(cont[order(cont$subj),c(6)], 1), "\\\\"
                        )
                      )

colnames(nrmsd.cont) = c.names2

write.table(nrmsd.cont, "tables/nrmsd-cont-ind.txt", quote=FALSE, row.names=FALSE)



#! best parameters for each subject (patient)

dt.iwa.sum  = read.table("data/dt-iwa-sum.txt", header=TRUE)

subj = cbind(rep("&", 7), as.character(dt.iwa.sum$subj))
prod.tm = cbind(rep("&", 7), m1[order(m1$subj),]$prod.tm)
prod.noise = cbind(rep("&", 7), m2[order(m2$subj),]$prod.noise)

par.mt = data.frame(matrix(c(t(subj), t(prod.tm), t(prod.noise)), ncol=14, byrow=TRUE))
par.mt = cbind(c("Participant", "Default action time", "Utility noise"), par.mt, rep("\\\\", 3))

write.table(par.mt, "tables/best-params-ind.txt", quote=FALSE, row.names=FALSE, col.names=FALSE)


#! Individual aphasic data
amp = rep("&", 7)

data.patients = 
data.frame(
  cbind(amp, dt.iwa.sum[,2], amp, round(dt.iwa.sum[,3]), 
        amp, round(dt.iwa.sum[,4]), paste("(", round(dt.iwa.sum[,5]), ")", sep=""), 
        amp, round(dt.iwa.sum[,6]), paste("(", round(dt.iwa.sum[,7]), ")", sep=""), 
        amp, round(dt.iwa.sum[,8]), paste("(", round(dt.iwa.sum[,9]), ")", sep=""), 
        amp, round(dt.iwa.sum[,10]), paste("(", round(dt.iwa.sum[,11]), ")", sep=""),
        rep("\\\\", 7)
  ),
  row.names=as.character(dt.iwa.sum[,1])
)

#colnames(data.patients) = c("Participant", "&", "SVO", "&", "OVS", "&", "SVO", "&", "OVS", "&", "SVO", "&", "OVS", "&")
write.table(data.patients, "tables/data-patients-ind.txt", quote=FALSE, row.names=FALSE, col.names=FALSE)



#! table with NRMSD values for aggregated data

acc.nrmsd = read.table("R-ACT-R/predictions/acc-nrmsd.txt", header=TRUE)
rt.nrmsd = read.table("R-ACT-R/predictions/rt-nrmsd.txt", header=TRUE)
em.nrmsd = read.table("R-ACT-R/predictions/em-nrmsd.txt", header=TRUE)

all.nrmsd = data.frame(rbind(acc.nrmsd, rt.nrmsd, em.nrmsd[,(3:7)]))

amp = rep("&", 6)

write.table(data.frame(
                    cbind(amp, all.nrmsd$tdhv1, amp, all.nrmsd$tdhv2, amp, 
                          all.nrmsd$m1, amp, all.nrmsd$m2, amp, all.nrmsd$m3, rep("\\\\", 6)
                          )
                    ), 
            "tables/nrmsd-all.txt", quote=FALSE, row.names=FALSE, col.names=FALSE
            )


#! table with individual NRMSD values for eye movements

em.nrmsd.ind = read.table("R-ACT-R/predictions/em-ind-nrmsd.txt", header=TRUE)

amp = rep("&", 28)
newline = rep("\\\\", 28)
cond = rep(c("Canonical", "Canonical", "Noncanonical", "Noncanonical"), 7)
acc = rep(c("Correct", "Incorrect"), 14)

write.table(data.frame(
                  cbind(as.character(em.nrmsd.ind$subj), amp, cond, amp, acc, amp, em.nrmsd.ind$tdhv1, 
                        amp, em.nrmsd.ind$tdhv2, amp, em.nrmsd.ind$m1, amp, em.nrmsd.ind$m2, 
                        amp, em.nrmsd.ind$m3, newline
                        )
                  ), 
            "tables/nrmsd-em-ind.txt", quote=FALSE, row.names=FALSE, col.names=FALSE
            )

