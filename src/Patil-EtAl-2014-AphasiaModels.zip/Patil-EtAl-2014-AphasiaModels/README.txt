
-> This folder contains all the R code used for the paper:
Umesh Patil, Sandra Hanne, Shravan Vasishth, Frank Burchert, and Ria De Bleser.
A computational evaluation of representational and processing accounts of aphasia.
Cognitive Science, 2014. In Press.


-> The R script 'run-all.R' executes the entire procedure of running all models, 
selecting the best parameters for each patient, generating plots and tables for the paper.


-> The R script 'global.R' specifies global variables. The variable 'sims' specifies the number
of simulations to run for each combination of parameters. For the paper we set sims to 1000.
NOTE: With sims=1000, it'll take around a day to run the entire code and the models will generate 
around 800MB of output. The code can be tested with lower values for sims, but then the 
output (plots, tables etc) won't look the same as in the paper.


-> How to run the entire code?
Call 'source("run-all.R")' within R from the root directory of the code. Plots and tables are generated 
in the corresponding folders in the root directory.

