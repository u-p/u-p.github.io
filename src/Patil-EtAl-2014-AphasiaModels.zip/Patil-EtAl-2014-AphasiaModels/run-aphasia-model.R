#
# Author: Umesh Patil (umesh.patil@gmail.com)
#


#! start fresh
rm(list=ls())
source("global.R")


#! load r-act-r
setwd("R-ACT-R")
source("functions.R")
source("act-r-params.R")


#! define the parameter space for M1, M2 & M3
dat <<- c(0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1)
egs <<- c(0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 
          0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2, 0.21, 0.22)
ans <<- c(0.15, 0.3, 0.45)

pars = expand.grid(dat, egs, ans)


#! 3 possible activation noise values for TDH models
ans.tdh <<- c(0.15, 0.3, 0.45)

#! total no. of parameter combinations
runs = dim(pars)[1]
#runs = 100
runs.tdh = length(ans.tdh)

#! no. of runs for each combination of parameters
#sims = 1


####################################
# Condition 1 (SVO) 
####################################

setwd("cond-1")
picCreStage = 4  		# picture creation stage
silenceStage = 12		# silence region stage

#------ run models: controls, M1, M2 & M3
source("global-var.R")

for(run in c(1:runs)){
	par.dat <<- pars[run,1]
	par.egs <<- pars[run,2]
	par.ans <<- pars[run,3]
	run.model("cond-1-model.R", "../output/CONT/cond-1/", run)
}

#------ run models: TDH-1, TDH-2
source("global-var.R")

for(run in c(1:runs.tdh)){
  par.dat <<- 0.02
  par.egs <<- 0.01
	par.ans <<- ans.tdh[run]
	run.model("cond-1-model-TDH.R", "../output/TDHv1/cond-1/", run)
	run.model("cond-1-model-TDH.R", "../output/TDHv2/cond-1/", run)
}


####################################
# Condition 2 (OVS) 
####################################

setwd("../cond-2")
picCreStage = 5  		# picture creation stage
silenceStage = 13		# silence region stage

#------ run models: controls, M1, M2 & M3
source("global-var.R")

for(run in c(1:runs)){
	par.dat <<- pars[run,1]
	par.egs <<- pars[run,2]
	par.ans <<- pars[run,3]
	run.model("cond-2-model.R", "../output/CONT/cond-2/", run)
}

#------ run models: TDH-1, TDH-2
source("global-var.R")

for(run in c(1:runs.tdh)){
  par.dat <<- 0.02
  par.egs <<- 0.01
	par.ans <<- ans.tdh[run]
	run.model("cond-2-model-TDHv1.R", "../output/TDHv1/cond-2/", run)
	run.model("cond-2-model-TDHv2.R", "../output/TDHv2/cond-2/", run)
}

setwd("../")


####################################
# Extract predictions
####################################

#! load utility functions
source(paste(HOME, "R-functions/utils.R", sep="/"))

dir="output/CONT"
out.cont = extractPredictions(runs, dir)
write.table(out.cont, file="predictions/cont.txt", row.names=FALSE)

dir="output/TDHv1"
out.cont = extractPredictions(runs.tdh, dir)
write.table(out.cont, file="predictions/tdhv1.txt", row.names=FALSE)

dir="output/TDHv2"
out.cont = extractPredictions(runs.tdh, dir)
write.table(out.cont, file="predictions/tdhv2.txt", row.names=FALSE)


#! go back to HOME
setwd(HOME)

