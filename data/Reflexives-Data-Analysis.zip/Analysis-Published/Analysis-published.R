
#---------------------
#  experiment design
#---------------------
#
# replication of Xiang et al 2009 'reflexive' part of the experiment, with one extra 'match-mismatch' condition
#
# cond a [match-match]: The dedicated firefighter that Henry recommended for the new job cut himself on broken glass on the floor.
# cond b [match-mis]  : The dedicated firefighter that Linda recommended for the new job cut himself on broken glass on the floor.
# cond c [mis-match]  : The dedicated firefighter that Linda recommended for the new job cut herself on broken glass on the floor.
# cond d [mis-mis]    : The dedicated firefighter that Henry recommended for the new job cut herself on broken glass on the floor.
#
#
# ret. cues: cat=np, role=subj, clause, gender
# cond a: np1 [cat, role, clause, gender]	-- np2 [cat, role, gender]	(4:3)
# cond b: np1 [cat, role, clause, gender]	-- np2 [cat, role]		    	(4:2)
# cond c: np1 [cat, role, clause]			    -- np2 [cat, role, gender]	(3:3)
# cond d: np1 [cat, role, clause]		    	-- np2 [cat, role]		    	(3:2)
#
#---------------------


#---------------------
#   libraries     
#---------------------

library(lme4)
library(MASS)


#------------
#   data
#------------

tmp <- read.table("allsubjects-etm-NewScreenVal.dat", header=TRUE)
items <- read.table("roi-words.txt")
colnames(items) <- c("item", "cond", "roi", "word")
tmp2 <- merge(tmp, items)
dt <- tmp2[order(tmp2$subj, tmp2$item, tmp2$roi),]
dt$cond <- dt$cond[,drop=TRUE]
dt$gend.rflx<- ifelse(dt$word=="himself", 1, -1)


# subject info
subjInfo = read.csv("subjInfo.csv", T)
colnames(subjInfo)[5] <- "gend.subj"
# no  		: no.
# subj 			: subj ID
# english 		: dialect (1=british, 2=canadian, 3=australian, 4=kiwi, 5=american)
# age			: age
# gend.subj		: subject's gender (0=female, 1=male)



# fixation info (extracted from the saccades package's output)
fixStat = read.table("fix-stat-v2.txt", T)
# subj				: subj ID
# trialMeanDur		: 
# fixMeanDur		: 
# perTrialFix		: 
# outFixProp		: percentage of fixations out region which got excluded from the data

dt.sub = merge(subjInfo, fixStat)[,c(1,3:8)]


# 141: accuracy below chance level (< 40%)
xsubj <- c(141)
dt <- subset(dt, !subj %in% xsubj)
dt$subj <- dt$subj[,drop=TRUE]


data = merge(dt, dt.sub)

data$item <- as.factor(data$item)
data$subj <- as.factor(data$subj)
data$english = as.factor(data$english)
data$gend.subj = as.factor(data$gend.subj)

##-- nested contrast coding --
cmat.6 <- matrix(c(-1/2, -1/2, +1/2, +1/2,
                   1,   -1,    0,    0,
                   0,    0,   -1,   +1),
                 4,  3
                 )

(inv.cmat.6 <- fractions(t(ginv(cmat.6)))) 
rownames(inv.cmat.6) <- c("a", "b", "c", "d")
colnames(inv.cmat.6) <- c(".Mismatch", ".MatchInt", ".MismInt")
contrasts(data$cond)<-inv.cmat.6


## data for region 12
data.12 = subset(data, roi==12)


#----- FFD -------
lmer.ffd <- lmer(log(FFD) ~ cond + 
                   scale(trial,scale=FALSE) +
                   (1+cond|subj) +
                   (1+cond|item), 
                 subset(data.12, FFD>0)
                 )

summary(lmer.ffd)

# does't converge!!
# lmer.ffd.0 <- lmer(log(FFD) ~ cond + 
#                    scale(trial,scale=FALSE) +
#                    (1+cond+scale(trial,scale=FALSE)|subj) +
#                    (1+cond+scale(trial,scale=FALSE)|item), 
#                  subset(data.12, FFD>0)
# )


## ---- Regression contingent analysis of FFD

# data with first pass regression
data.12.ffd.reg <- subset(data.12, FFD>0 & data.12$RBRC>0)
# data with NO first pass regression
data.12.ffd.noreg <- subset(data.12, FFD>0 & data.12$RBRC==0)


# FFDs followed by first pass regression
lmer.ffd.reg <- lmer(log(FFD) ~ cond + 
                   scale(trial,scale=FALSE) +
                   (1|subj) +
                   (1|item), 
                   data.12.ffd.reg
                   )

summary(lmer.ffd.reg)


# FFDs not followed by first pass regression
lmer.ffd.noreg <- lmer(log(FFD) ~ cond + 
                       scale(trial,scale=FALSE) +
                       (1|subj) +
                       (1|item), 
                     data.12.ffd.noreg
)

summary(lmer.ffd.noreg)
#---------------------------------------------------



#----- FPRT -------
lmer.fprt <- lmer(log(FPRT) ~ cond + 
                    scale(trial,scale=FALSE) +
                    (1+cond|subj) +
                    (1+cond|item), 
                  subset(data.12, FPRT>0)
                  )

summary(lmer.fprt)
#---------------------------------------------------



#----- RRT -------
lmer.rrt <- lmer(log(RRT) ~ cond + 
                   scale(trial,scale=FALSE) +
                   (1+cond|subj) +
                   (1+cond|item), 
                 subset(data.12, RRT>0)
)

summary(lmer.rrt)
#---------------------------------------------------



#----- TFT -------
lmer.tft <- lmer(log(TFT) ~ cond + 
                   scale(trial,scale=FALSE) +
                   (1+cond|subj) +
                   (1+cond|item), 
                 subset(data.12, TFT>0)
                 )

summary(lmer.tft)
#---------------------------------------------------



# --------- FPRP (first pass regression probability) --------
# FFD > 0: include only those data points where the word was fixated
data.12.fprp = subset(data.12, FFD>0)
data.12.fprp$fprp = ifelse(data.12.fprp$RBRC>0, 1, 0)

lmer.fprp.vanila <- glmer(fprp ~ cond + 
                     scale(trial,scale=FALSE) + 
                     (1|subj) + 
                     (1|item), 
                   family="binomial", 
                   data.12.fprp
)

summary(lmer.fprp.vanila)
#---------------------------------------------------



#----- RRP (re-reading probability) -------
data.12.rrp = data.12
data.12.rrp$rrp <- ifelse(data.12.rrp$RRTR>0, 1, 0)

lmer.rrp.vanila <- glmer(rrp ~ cond + 
                           scale(trial,scale=FALSE) + 
                           (1|subj) + 
                           (1|item), 
                         family="binomial", 
                         data.12.rrp
)

summary(lmer.rrp.vanila)



# doesn't converge!!
# lmer.rrp <- glmer(rrp ~ cond + 
#                     scale(trial,scale=FALSE) + 
#                     (1+cond|subj) + 
#                     (1+cond|item), 
#                   family="binomial", 
#                   data.12.rrp
#                   )
# 
# summary(lmer.rrp)
#---------------------------------------------------

